# CurriculumIQ — Knowledge Graph-Based Curriculum Intelligence for Industry Skill Alignment

An MCA Minor Project (5 credits / 100 marks) that builds a real, working curriculum-intelligence
platform: it extracts skills from academic curriculum and industry job descriptions using NLTK,
stores curriculum ↔ industry relationships as a Neo4j knowledge graph, runs NetworkX graph
analytics for industry demand and importance, and surfaces skill gaps and explainable
recommendations through a FastAPI + React application.

---

## 1. Problem Statement

University curricula are updated on a multi-year cycle, while industry skill requirements shift
continuously. There is no systematic, data-driven way to see *which* parts of a curriculum are
falling behind industry demand, *by how much*, and *what specifically* should be added. This
project builds that system for an MCA program.

## 2. Objectives

1. Develop a domain-specific knowledge graph linking academic course modules with evolving
   industry job requirements.
2. Implement a recommendation interface that highlights curriculum skill gaps for academic
   coordinators.
3. Evaluate mapping accuracy and gap-extraction efficiency against industry job-description
   datasets.

## 3. Features

- NLTK-based skill extraction pipeline (clean → tokenize → stopword removal → lemmatize →
  n-gram/regex skill matching → canonical normalization)
- Neo4j knowledge graph linking `Program → Course → Module → Topic → Skill` on the curriculum
  side and `Industry → JobRole → JobDescription → Skill` on the industry side, sharing canonical
  `Skill` nodes
- NetworkX-based analytics: job–skill bipartite graph, degree centrality as an industry-demand
  signal, graph statistics
- Skill-gap engine: basic alignment (`covered / required × 100`) and a documented weighted
  alignment formula based on industry demand
- Rule-based, explainable recommendation engine with HIGH / MEDIUM / LOW priority
- Real evaluation: Precision, Recall, F1 (micro-averaged) against a hand-labeled ground-truth set,
  plus a Mapping Accuracy metric for the normalization step
- A full React dashboard: Dashboard, Curriculum, Industry Jobs, Skills, interactive Knowledge
  Graph explorer, Skill Gap Analysis, Recommendations, Reports

## 4. Technology Stack

| Layer | Technology |
|---|---|
| Backend | Python, FastAPI |
| NLP | NLTK |
| Knowledge Graph | Neo4j |
| Graph Analysis | NetworkX |
| Frontend | React.js (Vite), Recharts, d3-force |
| Communication | REST APIs (JSON over HTTP) |

## 5. Architecture

```
Curriculum JSON ─┐                              ┌─ Job Description JSON
                 v                              v
        ┌──────────────────────────────────────────────┐
        │        NLTK NLP Pipeline (nlp_service.py)      │
        │  clean → tokenize → stopwords → lemmatize →    │
        │  n-gram/regex skill match → canonical Skill    │
        └───────────────────────┬────────────────────────┘
                                 v
                   ┌─────────────────────────┐
                   │   Neo4j Knowledge Graph   │
                   │ Program..Skill..JobRole   │
                   └─────────────┬─────────────┘
                     ┌───────────┴────────────┐
                     v                        v
          ┌────────────────────┐   ┌────────────────────┐
          │   NetworkX Layer    │   │  Gap Analysis Engine │
          │ (centrality/demand) │──>│ (covered/missing/    │
          └──────────┬──────────┘   │  alignment)          │
                     └───────────┬───┴──────────┬──────────┘
                                 v               v
                       ┌────────────────────────────────┐
                       │     Recommendation Engine        │
                       └─────────────────┬────────────────┘
                                         v
                                    FastAPI (REST)
                                         v
                                     React.js
                                Curriculum Intelligence
                                     Dashboard
```

## 6. Knowledge Graph Design

**Nodes:** `Program`, `Course`, `Module`, `Topic`, `Skill`, `Industry`, `JobRole`, `JobDescription`

**Relationships:** `HAS_COURSE`, `HAS_MODULE`, `HAS_TOPIC`, `COVERS`, `HAS_ROLE`,
`HAS_DESCRIPTION`, `REQUIRES`

Curriculum and industry both link into the **same canonical `Skill` node** (e.g. `React.js`),
which is what makes cross-domain analysis possible: a single Cypher traversal can walk from a
`Course` to its covered skills and from there to every `JobRole` that requires them.

Constraints (in `graph_service.py::CONSTRAINTS`) enforce uniqueness on `Skill.canonical_name` and
on every node's `id`, so ingestion is idempotent (`MERGE`, not `CREATE`).

## 7. NLTK Pipeline

See `backend/app/services/nlp_service.py`. Text is cleaned, tokenized, stripped of stopwords, and
lemmatized with `WordNetLemmatizer`. Matching against the controlled skill dictionary
(`datasets/skill_dictionary/skills.json`) happens two ways: n-grams of the lemmatized tokens (for
plain word/phrase skills like "Machine Learning"), and a punctuation-safe regex pass over the
cleaned text (for skills like `React.js`, `C++`, `CI/CD` that generic tokenizers would mangle).
Both routes feed into one deduplicated, normalized skill set.

## 8. NetworkX Usage

Neo4j answers relationship queries. NetworkX (`networkx_service.py`) builds an **in-memory
bipartite graph** of `JobDescription <-> Skill` edges and computes:
- degree centrality per skill (used as the industry-demand weight)
- job-skill graph statistics (density, average skills per job)

These numbers feed directly into the weighted alignment formula and recommendation priority — a
real graph-theoretic computation, not just a stored count.

## 9. Skill-Gap Algorithm

```
covered  = curriculum_skills ∩ industry_skills
missing  = industry_skills − curriculum_skills
critical = missing skills with demand% >= 70

basic_alignment    = covered_count / required_count × 100
weighted_alignment = Σ demand%(covered) / Σ demand%(required) × 100
```

## 10. Recommendation Algorithm

For every missing skill: `demand% >= 70 → HIGH`, `40–69% → MEDIUM`, `< 40% → LOW`. Recommendation
text is templated per skill **category** (Frontend, Backend, DevOps & Cloud, etc.) — see
`recommendation_service.CATEGORY_TEMPLATES` — so the logic stays a transparent lookup table, not
free-form generated text.

## 11. Evaluation

Run against `datasets/ground_truth/labeled_jobs.json` (40 hand-labeled samples):

- **Precision / Recall / F1** (micro-averaged) measure extraction quality
- **Mapping Accuracy** measures normalization correctness: every alias in the skill dictionary is
  checked against its declared canonical skill

On the shipped datasets this currently computes to **Precision ≈ 96.7%, Recall = 100%, F1 ≈
98.3%, Mapping Accuracy = 100%** — all computed live by `GET /api/evaluation`, never hard-coded.
(The small number of false positives comes from generic filler phrases like "in an agile
environment" in the templated job descriptions being — correctly — picked up as a mention of the
Agile skill, even though it wasn't in the ground-truth labeler's explicit skill list. It's a good
real-world example of a precision/recall tradeoff to discuss in a viva.)

## 12. Project Structure

```
curriculum-intelligence/
├── backend/                  # FastAPI app (see app/api, app/services, app/database, app/utils)
├── datasets/                 # curriculum, job_descriptions, skill_dictionary, ground_truth
├── frontend/                 # React (Vite) app
├── docs/                     # architecture notes, diagrams, screenshots, evaluation output
└── README.md
```

## 13. Installation & Setup

### Prerequisites
- Python 3.10+
- Node.js 18+
- A running Neo4j instance (Neo4j Desktop, or `docker run` if you have Docker available) —
  Community Edition is sufficient

### Neo4j Setup (the one manual step)
1. Install [Neo4j Desktop](https://neo4j.com/download/) (or run
   `docker run -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/your_password neo4j:5`).
2. Create/start a database and note its Bolt URI (typically `bolt://localhost:7687`), username
   (`neo4j`) and the password you set.
3. Copy `backend/.env.example` to `backend/.env` and fill in `NEO4J_URI`, `NEO4J_USERNAME`,
   `NEO4J_PASSWORD`.

### Backend Setup
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # then edit .env with your Neo4j credentials
uvicorn app.main:app --reload --port 8000
```
On first run (or whenever you want to rebuild the graph from the JSON datasets), call:
```bash
curl -X POST http://localhost:8000/api/admin/reingest
```
This wipes and repopulates the graph from `datasets/`. Re-run it any time you edit a dataset file.

Interactive API docs: http://localhost:8000/docs

### Frontend Setup
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

### Running Tests
```bash
cd backend
python -m pytest tests/ -v
```
18 tests cover skill normalization, extraction, alignment/gap calculation, recommendation
priority, NetworkX demand/statistics, and evaluation metrics — none require a live Neo4j
connection.

## 14. Dataset Information

- `datasets/curriculum/curriculum.json` — MCA program, 5 courses, modules/topics with real
  descriptions for the NLP pipeline to process
- `datasets/job_descriptions/jobs.json` — 91 generated job postings across 9 roles (Full Stack
  Developer, Frontend Developer, Backend Developer, Data Analyst, Data Scientist, ML Engineer,
  Cloud Engineer, DevOps Engineer, Mobile App Developer), each with a varied skill subset so
  demand percentages are meaningful rather than trivial
- `datasets/skill_dictionary/skills.json` — 65+ canonical skills with aliases and categories
- `datasets/ground_truth/labeled_jobs.json` — 40 hand-labeled samples for evaluation

`backend/data/generate_jobs.py` is the (re-runnable) generator script used to build the job and
ground-truth datasets.

## 15. Future Scope

- Expand the skill dictionary and add a lightweight synonym-suggestion step for unmatched terms
- Support curriculum file upload (PDF/DOCX syllabus parsing) instead of hand-authored JSON
- Add authentication for academic-coordinator accounts if the project scope is extended beyond
  this Minor Project
- Track alignment trends over multiple curriculum revisions over time

## 16. Screenshots

_Add screenshots of the running application here (`docs/screenshots/`) once you have Neo4j
running locally — Dashboard, Knowledge Graph Explorer, and Skill Gap Analysis are the strongest
ones to include for the report._
