import { useState } from "react";
import { Routes, Route, useLocation } from "react-router-dom";

import Sidebar from "./components/layout/Sidebar.jsx";
import Topbar from "./components/layout/Topbar.jsx";

import Dashboard from "./pages/Dashboard.jsx";
import Curriculum from "./pages/Curriculum.jsx";
import CourseDetail from "./pages/CourseDetail.jsx";
import Jobs from "./pages/Jobs.jsx";
import Skills from "./pages/Skills.jsx";
import KnowledgeGraph from "./pages/KnowledgeGraph.jsx";
import SkillGap from "./pages/SkillGap.jsx";
import Recommendations from "./pages/Recommendations.jsx";
import Reports from "./pages/Reports.jsx";

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="app-shell">
      <Sidebar open={menuOpen} onNavigate={() => setMenuOpen(false)} />
      <div className="app-main">
        <Topbar pathname={location.pathname} onMenuClick={() => setMenuOpen((v) => !v)} />
        <main className="app-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/curriculum" element={<Curriculum />} />
            <Route path="/curriculum/:courseId" element={<CourseDetail />} />
            <Route path="/jobs" element={<Jobs />} />
            <Route path="/skills" element={<Skills />} />
            <Route path="/knowledge-graph" element={<KnowledgeGraph />} />
            <Route path="/skill-gap" element={<SkillGap />} />
            <Route path="/recommendations" element={<Recommendations />} />
            <Route path="/reports" element={<Reports />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
