import { useMemo, useState } from "react";
import { api } from "../services/api.js";
import { useApiData } from "../hooks/useApiData.js";
import { LoadingState, ErrorState, EmptyState } from "../components/common/StatusStates.jsx";
import { SearchInput, FilterSelect } from "../components/common/Inputs.jsx";
import DataTable from "../components/tables/DataTable.jsx";

export default function Jobs() {
  const [search, setSearch] = useState("");
  const [roleId, setRoleId] = useState("");
  const [selectedJob, setSelectedJob] = useState(null);

  const { data, loading, error, refetch } = useApiData(
    () => api.getJobs({ search: search || undefined, role_id: roleId || undefined }),
    [search, roleId]
  );

  const roleOptions = useMemo(
    () => (data?.roles || []).map((r) => ({ value: r.id, label: `${r.title} (${r.job_count})` })),
    [data]
  );

  const columns = [
    { key: "title", header: "Job Title" },
    { key: "company", header: "Company" },
    { key: "industry", header: "Industry" },
    { key: "location", header: "Location" },
    {
      key: "skills",
      header: "Skills",
      render: (row) => (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 4, maxWidth: 320 }}>
          {row.skills.slice(0, 4).map((s) => (
            <span key={s} className="badge badge-neutral">{s}</span>
          ))}
          {row.skills.length > 4 && <span className="text-muted" style={{ fontSize: 12 }}>+{row.skills.length - 4} more</span>}
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="page-header">
        <h1>Industry Jobs</h1>
        <p>Explore the job-description dataset and the skills required by each role.</p>
      </div>

      <div style={{ display: "flex", gap: 12, marginBottom: 18, flexWrap: "wrap" }}>
        <SearchInput value={search} onChange={setSearch} placeholder="Search by title or company…" />
        <FilterSelect value={roleId} onChange={setRoleId} options={roleOptions} placeholder="All Job Roles" />
      </div>

      {loading && <LoadingState label="Loading job descriptions" />}
      {error && <ErrorState message={error} onRetry={refetch} />}

      {!loading && !error && data && (
        data.jobs.length === 0 ? (
          <EmptyState title="No jobs match your filters" />
        ) : (
          <div className="card">
            <DataTable columns={columns} rows={data.jobs} onRowClick={setSelectedJob} />
          </div>
        )
      )}

      {selectedJob && (
        <div className="card card-padded" style={{ marginTop: 20 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <p className="section-title" style={{ marginBottom: 4 }}>{selectedJob.title}</p>
              <p className="text-secondary" style={{ fontSize: 13.5 }}>
                {selectedJob.company} · {selectedJob.industry} · {selectedJob.location}
              </p>
            </div>
            <button className="btn btn-secondary" onClick={() => setSelectedJob(null)}>Close</button>
          </div>
          <p style={{ fontSize: 14, lineHeight: 1.6, marginTop: 14 }}>{selectedJob.description}</p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 14 }}>
            {selectedJob.skills.map((s) => (
              <span key={s} className="badge badge-neutral">{s}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
