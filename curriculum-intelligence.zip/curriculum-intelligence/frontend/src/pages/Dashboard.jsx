import { useMemo } from "react";
import { Link } from "react-router-dom";
import { api } from "../services/api.js";
import { useApiData } from "../hooks/useApiData.js";
import { LoadingState, ErrorState } from "../components/common/StatusStates.jsx";
import KpiCard from "../components/common/KpiCard.jsx";
import AlignmentGauge from "../components/charts/AlignmentGauge.jsx";
import SkillDemandList from "../components/charts/SkillDemandList.jsx";
import ComparisonBarChart from "../components/charts/ComparisonBarChart.jsx";
import { PriorityBadge } from "../components/common/Badge.jsx";

export default function Dashboard() {
  const { data, loading, error, refetch } = useApiData(() => api.getDashboard(), []);

  const comparisonData = useMemo(() => {
    if (!data) return [];
    const coveredSet = new Set(data.covered_curriculum_skills || []);
    return (data.top_industry_skills || []).slice(0, 8).map((row) => ({
      skill: row.skill,
      industryDemand: row.demand_percentage,
      curriculumCoverage: coveredSet.has(row.skill) ? 100 : 0,
    }));
  }, [data]);

  if (loading) return <LoadingState label="Loading dashboard metrics" />;
  if (error) return <ErrorState message={error} onRetry={refetch} />;
  if (!data) return null;

  return (
    <div>
      <div className="page-header">
        <h1>Curriculum Intelligence Dashboard</h1>
        <p>Track curriculum relevance, industry skill demand and academic alignment.</p>
      </div>

      <div className="grid grid-4" style={{ marginBottom: 20 }}>
        <KpiCard label="Total Courses" value={data.total_courses} />
        <KpiCard label="Skills Identified" value={data.total_skills} accent="teal" />
        <KpiCard label="Job Descriptions Analyzed" value={data.total_jobs_analyzed} />
        <KpiCard label="Industry Alignment" value={data.overall_alignment_percentage} suffix="%" accent="teal" />
      </div>

      <div className="grid grid-2" style={{ marginBottom: 20 }}>
        <div className="card card-padded">
          <p className="section-title">Top Industry Skills</p>
          <SkillDemandList items={data.top_industry_skills} />
        </div>
        <div className="card card-padded" style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          <p className="section-title" style={{ alignSelf: "flex-start" }}>Industry Alignment</p>
          <AlignmentGauge value={data.overall_alignment_percentage} label="dataset-wide, unweighted" size={150} />
        </div>
      </div>

      <div className="grid grid-2" style={{ marginBottom: 20 }}>
        <div className="card card-padded">
          <p className="section-title">Curriculum vs Industry</p>
          <ComparisonBarChart data={comparisonData} />
        </div>
        <div className="card card-padded">
          <p className="section-title">Critical Skill Gaps</p>
          {data.critical_skill_gaps.length === 0 ? (
            <p className="text-secondary">No high-priority gaps detected across the current dataset.</p>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {data.critical_skill_gaps.map((gap) => (
                <div key={gap.skill} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontWeight: 500 }}>{gap.skill}</span>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span className="mono text-secondary">{gap.demand_percentage}%</span>
                    <PriorityBadge priority={gap.priority} />
                  </div>
                </div>
              ))}
            </div>
          )}
          <Link to="/recommendations" style={{ display: "inline-block", marginTop: 14, fontSize: 13.5, color: "var(--color-primary)", fontWeight: 600 }}>
            View full recommendations →
          </Link>
        </div>
      </div>

      <div className="card card-padded">
        <p className="section-title">Graph Analytics Snapshot</p>
        <p className="text-secondary" style={{ fontSize: 13.5, marginBottom: 12 }}>
          Computed live by NetworkX over the job–skill bipartite graph.
        </p>
        <div className="grid grid-4">
          <MiniStat label="Job Nodes" value={data.graph_statistics.job_nodes} />
          <MiniStat label="Skill Nodes" value={data.graph_statistics.skill_nodes} />
          <MiniStat label="Graph Edges" value={data.graph_statistics.edges} />
          <MiniStat label="Avg Skills / Job" value={data.graph_statistics.average_skills_per_job} />
        </div>
      </div>
    </div>
  );
}

function MiniStat({ label, value }) {
  return (
    <div>
      <p className="text-muted" style={{ fontSize: 12 }}>{label}</p>
      <p className="mono" style={{ fontSize: 20, fontWeight: 600 }}>{value}</p>
    </div>
  );
}
