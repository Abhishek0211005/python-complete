import { useState } from "react";
import { api } from "../services/api.js";
import { useApiData } from "../hooks/useApiData.js";
import { LoadingState, ErrorState, EmptyState } from "../components/common/StatusStates.jsx";
import AlignmentGauge from "../components/charts/AlignmentGauge.jsx";
import { CoverageBadge } from "../components/common/Badge.jsx";

export default function SkillGap() {
  const { data: options, loading: optionsLoading, error: optionsError } = useApiData(
    () => api.getAnalysisOptions(),
    []
  );

  const [courseId, setCourseId] = useState("");
  const [roleId, setRoleId] = useState("");
  const [result, setResult] = useState(null);
  const [running, setRunning] = useState(false);
  const [runError, setRunError] = useState(null);

  async function runAnalysis() {
    if (!courseId || !roleId) return;
    setRunning(true);
    setRunError(null);
    try {
      const res = await api.analyzeGap({ course_id: courseId, role_id: roleId });
      setResult(res);
    } catch (err) {
      setRunError(err.message);
    } finally {
      setRunning(false);
    }
  }

  if (optionsLoading) return <LoadingState label="Loading options" />;
  if (optionsError) return <ErrorState message={optionsError} />;

  return (
    <div>
      <div className="page-header">
        <h1>Skill Gap Analysis</h1>
        <p>Compare a course against a target job role to see alignment and gaps.</p>
      </div>

      <div className="card card-padded" style={{ marginBottom: 22 }}>
        <div style={{ display: "flex", gap: 14, flexWrap: "wrap", alignItems: "flex-end" }}>
          <div>
            <p className="text-secondary" style={{ fontSize: 12.5, marginBottom: 6 }}>Course</p>
            <select className="select" value={courseId} onChange={(e) => setCourseId(e.target.value)}>
              <option value="">Select a course</option>
              {options.courses.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <div>
            <p className="text-secondary" style={{ fontSize: 12.5, marginBottom: 6 }}>Target Job Role</p>
            <select className="select" value={roleId} onChange={(e) => setRoleId(e.target.value)}>
              <option value="">Select a job role</option>
              {options.roles.map((r) => (
                <option key={r.id} value={r.id}>{r.title} ({r.job_count} postings)</option>
              ))}
            </select>
          </div>
          <button className="btn btn-primary" disabled={!courseId || !roleId || running} onClick={runAnalysis}>
            {running ? "Analyzing…" : "Analyze Alignment"}
          </button>
        </div>
      </div>

      {runError && <ErrorState message={runError} onRetry={runAnalysis} />}

      {!result && !runError && (
        <EmptyState
          title="Select a course and job role to begin"
          hint="Alignment, covered skills, missing skills and priority are all calculated live."
        />
      )}

      {result && (
        <div>
          <div className="grid grid-2" style={{ marginBottom: 20 }}>
            <div className="card card-padded" style={{ display: "flex", gap: 30, alignItems: "center", flexWrap: "wrap" }}>
              <AlignmentGauge value={result.basic_alignment_percentage} label="Basic Alignment" />
              <AlignmentGauge value={result.weighted_alignment_percentage} label="Weighted Alignment" />
              <div>
                <p className="text-secondary" style={{ fontSize: 13, lineHeight: 1.6 }}>
                  <strong className="mono">{result.covered_skill_count}</strong> of{" "}
                  <strong className="mono">{result.required_skill_count}</strong> industry-required skills
                  are covered by this course.
                </p>
              </div>
            </div>
            <div className="card card-padded">
              <p className="section-title">Critical Skill Gaps</p>
              {result.critical_skills.length === 0 ? (
                <p className="text-secondary" style={{ fontSize: 13.5 }}>
                  No missing skill currently exceeds the 70% high-demand threshold.
                </p>
              ) : (
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {result.critical_skills.map((s) => (
                    <span key={s} className="badge badge-high">{s}</span>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-2">
            <div className="card card-padded">
              <p className="section-title">Covered Skills ({result.covered_skills.length})</p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {result.covered_skills.map((s) => (
                  <span key={s} className="badge badge-covered">{s}</span>
                ))}
              </div>
            </div>
            <div className="card card-padded">
              <p className="section-title">Missing Skills ({result.missing_skills.length})</p>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {result.missing_skills.map((s) => (
                  <div key={s} style={{ display: "flex", justifyContent: "space-between", fontSize: 13.5 }}>
                    <span>{s}</span>
                    <span className="mono text-secondary">
                      {result.skill_demand[s]?.demand_percentage}% demand
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
