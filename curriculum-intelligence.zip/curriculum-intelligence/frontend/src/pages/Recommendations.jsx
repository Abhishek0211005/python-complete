import { useMemo, useState } from "react";
import { api } from "../services/api.js";
import { useApiData } from "../hooks/useApiData.js";
import { LoadingState, ErrorState, EmptyState } from "../components/common/StatusStates.jsx";
import { PriorityBadge, CategoryBadge } from "../components/common/Badge.jsx";

const GROUPS = ["HIGH", "MEDIUM", "LOW"];

export default function Recommendations() {
  const { data: options, loading: optionsLoading, error: optionsError } = useApiData(
    () => api.getAnalysisOptions(),
    []
  );
  const [courseId, setCourseId] = useState("");
  const [roleId, setRoleId] = useState("");

  const { data, loading, error, refetch } = useApiData(
    () => api.getRecommendations(courseId, roleId),
    [courseId, roleId],
    { skip: !courseId || !roleId }
  );

  const grouped = useMemo(() => {
    if (!data) return {};
    const g = { HIGH: [], MEDIUM: [], LOW: [] };
    for (const rec of data.recommendations) g[rec.priority].push(rec);
    return g;
  }, [data]);

  if (optionsLoading) return <LoadingState label="Loading options" />;
  if (optionsError) return <ErrorState message={optionsError} />;

  return (
    <div>
      <div className="page-header">
        <h1>Recommendations</h1>
        <p>Explainable, priority-ranked suggestions for closing curriculum gaps.</p>
      </div>

      <div className="card card-padded" style={{ marginBottom: 22, display: "flex", gap: 14, flexWrap: "wrap" }}>
        <div>
          <p className="text-secondary" style={{ fontSize: 12.5, marginBottom: 6 }}>Course</p>
          <select className="select" value={courseId} onChange={(e) => setCourseId(e.target.value)}>
            <option value="">Select a course</option>
            {options.courses.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <div>
          <p className="text-secondary" style={{ fontSize: 12.5, marginBottom: 6 }}>Target Job Role</p>
          <select className="select" value={roleId} onChange={(e) => setRoleId(e.target.value)}>
            <option value="">Select a job role</option>
            {options.roles.map((r) => (
              <option key={r.id} value={r.id}>{r.title}</option>
            ))}
          </select>
        </div>
      </div>

      {!courseId || !roleId ? (
        <EmptyState title="Select a course and job role" hint="Recommendations are generated live from the current skill gap." />
      ) : loading ? (
        <LoadingState label="Generating recommendations" />
      ) : error ? (
        <ErrorState message={error} onRetry={refetch} />
      ) : data.recommendations.length === 0 ? (
        <EmptyState title="No gaps found" hint={`${data.course} already covers every skill required for ${data.role}.`} />
      ) : (
        GROUPS.map((group) =>
          grouped[group].length === 0 ? null : (
            <div key={group} style={{ marginBottom: 22 }}>
              <p className="section-title" style={{ display: "flex", alignItems: "center", gap: 8 }}>
                {group} PRIORITY <span className="text-muted" style={{ fontWeight: 400 }}>({grouped[group].length})</span>
              </p>
              <div className="grid grid-2">
                {grouped[group].map((rec) => (
                  <div key={rec.skill} className="card card-padded">
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                      <div>
                        <p style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 16 }}>{rec.skill}</p>
                        <div style={{ marginTop: 6 }}><CategoryBadge category={rec.category} /></div>
                      </div>
                      <PriorityBadge priority={rec.priority} />
                    </div>
                    <div style={{ display: "flex", gap: 18, marginTop: 14, fontSize: 13 }}>
                      <div>
                        <p className="text-muted" style={{ fontSize: 11.5 }}>Industry Demand</p>
                        <p className="mono" style={{ fontWeight: 600 }}>{rec.industry_demand_percentage}%</p>
                      </div>
                      <div>
                        <p className="text-muted" style={{ fontSize: 11.5 }}>Jobs Requiring It</p>
                        <p className="mono" style={{ fontWeight: 600 }}>{rec.jobs_requiring}/{rec.total_relevant_jobs}</p>
                      </div>
                    </div>
                    <p className="text-secondary" style={{ fontSize: 13.5, marginTop: 12, lineHeight: 1.5 }}>{rec.reason}</p>
                    <p style={{ fontSize: 13.5, marginTop: 10, lineHeight: 1.5, fontWeight: 500 }}>{rec.recommendation}</p>
                  </div>
                ))}
              </div>
            </div>
          )
        )
      )}
    </div>
  );
}
