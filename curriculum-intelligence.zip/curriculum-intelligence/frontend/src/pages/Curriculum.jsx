import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../services/api.js";
import { useApiData } from "../hooks/useApiData.js";
import { LoadingState, ErrorState, EmptyState } from "../components/common/StatusStates.jsx";
import { SearchInput } from "../components/common/Inputs.jsx";

export default function Curriculum() {
  const { data, loading, error, refetch } = useApiData(() => api.getCurriculum(), []);
  const [search, setSearch] = useState("");
  const navigate = useNavigate();

  const filteredCourses = useMemo(() => {
    if (!data) return [];
    const term = search.trim().toLowerCase();
    if (!term) return data.courses;
    return data.courses.filter((c) => c.name.toLowerCase().includes(term));
  }, [data, search]);

  if (loading) return <LoadingState label="Loading curriculum" />;
  if (error) return <ErrorState message={error} onRetry={refetch} />;
  if (!data) return null;

  return (
    <div>
      <div className="page-header">
        <h1>Curriculum Explorer</h1>
        <p>Browse programs, courses, modules, topics and the skills extracted from them.</p>
      </div>

      <div style={{ marginBottom: 18 }}>
        <SearchInput value={search} onChange={setSearch} placeholder="Search courses…" />
      </div>

      {filteredCourses.length === 0 ? (
        <EmptyState title="No courses match your search" />
      ) : (
        <div className="grid grid-4">
          {filteredCourses.map((course) => (
            <div
              key={course.id}
              className="card card-padded"
              style={{ cursor: "pointer" }}
              onClick={() => navigate(`/curriculum/${course.id}`)}
            >
              <p className="text-muted" style={{ fontSize: 12 }}>{course.program}</p>
              <p style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 16, marginTop: 6 }}>
                {course.name}
              </p>
              <p className="text-secondary" style={{ fontSize: 13, marginTop: 10 }}>View modules &amp; skills →</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
