import { useState } from "react";
import { api } from "../services/api.js";
import { useApiData } from "../hooks/useApiData.js";
import { LoadingState, ErrorState } from "../components/common/StatusStates.jsx";
import { FilterSelect } from "../components/common/Inputs.jsx";
import GraphCanvas from "../components/graph/GraphCanvas.jsx";
import NodeDetailPanel from "../components/graph/NodeDetailPanel.jsx";

const NODE_TYPE_OPTIONS = [
  { value: "Program", label: "Programs" },
  { value: "Course", label: "Courses" },
  { value: "Skill", label: "Skills" },
  { value: "JobRole", label: "Job Roles" },
  { value: "Industry", label: "Industries" },
];

export default function KnowledgeGraph() {
  const [nodeType, setNodeType] = useState("");
  const [selectedNode, setSelectedNode] = useState(null);

  const { data, loading, error, refetch } = useApiData(
    () => api.getGraph({ node_type: nodeType || undefined, limit: 90 }),
    [nodeType]
  );

  return (
    <div>
      <div className="page-header">
        <h1>Knowledge Graph Explorer</h1>
        <p>Visualize how curriculum and industry connect through shared skills. Scroll to zoom, drag to pan, click a node to inspect it.</p>
      </div>

      <div style={{ marginBottom: 16 }}>
        <FilterSelect value={nodeType} onChange={setNodeType} options={NODE_TYPE_OPTIONS} placeholder="All Node Types (filtered subgraph)" />
      </div>

      <div className="grid grid-2" style={{ alignItems: "flex-start" }}>
        <div className="card card-padded">
          {loading && <LoadingState label="Building graph" />}
          {error && <ErrorState message={error} onRetry={refetch} />}
          {!loading && !error && (
            <GraphCanvas graphData={data} onNodeClick={setSelectedNode} height={480} />
          )}
        </div>
        {selectedNode ? (
          <NodeDetailPanel node={selectedNode} onClose={() => setSelectedNode(null)} />
        ) : (
          <div className="card card-padded">
            <p className="section-title">Node Details</p>
            <p className="text-secondary" style={{ fontSize: 13.5 }}>
              Click any node in the graph to see its relationships — curriculum coverage and industry demand for skills, or connected courses/roles for other node types.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
