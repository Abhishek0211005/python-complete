import { api } from "../services/api.js";
import { useApiData } from "../hooks/useApiData.js";
import { LoadingState, ErrorState } from "../components/common/StatusStates.jsx";
import KpiCard from "../components/common/KpiCard.jsx";
import SkillDemandList from "../components/charts/SkillDemandList.jsx";

export default function Reports() {
  const { data: dashboard, loading: l1, error: e1 } = useApiData(() => api.getDashboard(), []);
  const { data: evaluation, loading: l2, error: e2 } = useApiData(() => api.getEvaluation(), []);

  if (l1 || l2) return <LoadingState label="Compiling reports" />;
  if (e1 || e2) return <ErrorState message={e1 || e2} />;
  if (!dashboard || !evaluation) return null;

  const { extraction, mapping_accuracy } = evaluation;

  return (
    <div>
      <div className="page-header">
        <h1>Reports &amp; Evaluation</h1>
        <p>Aggregate reporting and NLP extraction evaluation metrics.</p>
      </div>

      <div className="card card-padded" style={{ marginBottom: 20 }}>
        <p className="section-title">Curriculum Alignment Report</p>
        <div className="grid grid-4">
          <KpiCard label="Overall Alignment" value={dashboard.overall_alignment_percentage} suffix="%" accent="teal" />
          <KpiCard label="Total Courses" value={dashboard.total_courses} />
          <KpiCard label="Skills Tracked" value={dashboard.total_skills} />
          <KpiCard label="Job Descriptions" value={dashboard.total_jobs_analyzed} />
        </div>
      </div>

      <div className="grid grid-2" style={{ marginBottom: 20 }}>
        <div className="card card-padded">
          <p className="section-title">Top Industry Skills</p>
          <SkillDemandList items={dashboard.top_industry_skills} />
        </div>
        <div className="card card-padded">
          <p className="section-title">Missing Skills Report (High Priority)</p>
          {dashboard.critical_skill_gaps.length === 0 ? (
            <p className="text-secondary" style={{ fontSize: 13.5 }}>No high-priority gaps in the current dataset.</p>
          ) : (
            <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13.5, lineHeight: 2 }}>
              {dashboard.critical_skill_gaps.map((g) => (
                <li key={g.skill}>{g.skill} — {g.demand_percentage}% demand</li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="card card-padded" style={{ marginBottom: 20 }}>
        <p className="section-title">NLP Skill Extraction Evaluation</p>
        <p className="text-secondary" style={{ fontSize: 13, marginBottom: 14 }}>
          Computed against a {extraction.sample_size}-sample hand-labeled ground-truth set.
        </p>
        <div className="grid grid-4">
          <KpiCard label="Precision" value={(extraction.precision * 100).toFixed(1)} suffix="%" />
          <KpiCard label="Recall" value={(extraction.recall * 100).toFixed(1)} suffix="%" accent="teal" />
          <KpiCard label="F1 Score" value={(extraction.f1_score * 100).toFixed(1)} suffix="%" />
          <KpiCard label="Mapping Accuracy" value={mapping_accuracy.mapping_accuracy_percentage} suffix="%" accent="teal" />
        </div>
        <p className="text-muted" style={{ fontSize: 12, marginTop: 14 }}>
          TP {extraction.true_positives} · FP {extraction.false_positives} · FN {extraction.false_negatives} ·{" "}
          {mapping_accuracy.correct_mappings}/{mapping_accuracy.total_alias_checks} alias mappings verified correct
        </p>
      </div>
    </div>
  );
}
