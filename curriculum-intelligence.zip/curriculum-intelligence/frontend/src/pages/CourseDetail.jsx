import { useParams, Link } from "react-router-dom";
import { api } from "../services/api.js";
import { useApiData } from "../hooks/useApiData.js";
import { LoadingState, ErrorState } from "../components/common/StatusStates.jsx";

export default function CourseDetail() {
  const { courseId } = useParams();
  const { data, loading, error, refetch } = useApiData(() => api.getCourse(courseId), [courseId]);

  if (loading) return <LoadingState label="Loading course" />;
  if (error) return <ErrorState message={error} onRetry={refetch} />;
  if (!data) return null;

  return (
    <div>
      <Link to="/curriculum" className="text-secondary" style={{ fontSize: 13, fontWeight: 600 }}>
        ← Back to Curriculum
      </Link>
      <div className="page-header" style={{ marginTop: 10 }}>
        <h1>{data.name}</h1>
        <p>{data.modules.length} modules · {data.skills.length} distinct skills extracted</p>
      </div>

      <div className="card card-padded" style={{ marginBottom: 20 }}>
        <p className="section-title">All Skills Detected in This Course</p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          {data.skills.map((skill) => (
            <span key={skill} className="badge badge-neutral">{skill}</span>
          ))}
        </div>
      </div>

      {data.modules.map((module) => (
        <div className="card card-padded" key={module.id} style={{ marginBottom: 16 }}>
          <p className="section-title">{module.name}</p>
          {module.topics.map((topic) => (
            <div key={topic.id} style={{ paddingBottom: 14, marginBottom: 14, borderBottom: "1px solid var(--color-border)" }}>
              <p style={{ fontWeight: 600, fontSize: 14.5 }}>{topic.name}</p>
              <p className="text-secondary" style={{ fontSize: 13.5, marginTop: 6, lineHeight: 1.5 }}>
                {topic.description}
              </p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
                {topic.skills.map((skill) => (
                  <span key={skill} className="badge badge-covered">{skill}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
