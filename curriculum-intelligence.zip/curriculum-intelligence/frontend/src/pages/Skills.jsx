import { useMemo, useState } from "react";
import { api } from "../services/api.js";
import { useApiData } from "../hooks/useApiData.js";
import { LoadingState, ErrorState, EmptyState } from "../components/common/StatusStates.jsx";
import { SearchInput } from "../components/common/Inputs.jsx";
import { CoverageBadge, CategoryBadge, PriorityBadge } from "../components/common/Badge.jsx";
import DataTable from "../components/tables/DataTable.jsx";

function priorityFor(jobCount, maxJobCount) {
  if (maxJobCount === 0) return "LOW";
  const pct = (jobCount / maxJobCount) * 100;
  if (pct >= 70) return "HIGH";
  if (pct >= 40) return "MEDIUM";
  return "LOW";
}

export default function Skills() {
  const { data, loading, error, refetch } = useApiData(() => api.getSkills(), []);
  const [search, setSearch] = useState("");

  const maxJobCount = useMemo(() => {
    if (!data) return 0;
    return Math.max(1, ...data.skills.map((s) => s.job_count));
  }, [data]);

  const filtered = useMemo(() => {
    if (!data) return [];
    const term = search.trim().toLowerCase();
    if (!term) return data.skills;
    return data.skills.filter((s) => s.skill.toLowerCase().includes(term));
  }, [data, search]);

  const columns = [
    { key: "skill", header: "Skill" },
    { key: "category", header: "Category", render: (row) => <CategoryBadge category={row.category} /> },
    {
      key: "coverage",
      header: "Curriculum Coverage",
      render: (row) => <CoverageBadge covered={row.covered_by_courses.length > 0} />,
    },
    { key: "job_count", header: "Relevant Jobs" },
    {
      key: "roles",
      header: "Related Job Roles",
      render: (row) => (
        <span className="text-secondary" style={{ fontSize: 13 }}>
          {row.required_by_roles.slice(0, 2).join(", ")}
          {row.required_by_roles.length > 2 ? ` +${row.required_by_roles.length - 2}` : ""}
        </span>
      ),
    },
    {
      key: "priority",
      header: "Priority",
      render: (row) =>
        row.covered_by_courses.length > 0 ? (
          <span className="text-muted" style={{ fontSize: 13 }}>—</span>
        ) : (
          <PriorityBadge priority={priorityFor(row.job_count, maxJobCount)} />
        ),
    },
  ];

  if (loading) return <LoadingState label="Loading skill intelligence" />;
  if (error) return <ErrorState message={error} onRetry={refetch} />;
  if (!data) return null;

  return (
    <div>
      <div className="page-header">
        <h1>Skill Intelligence</h1>
        <p>See curriculum coverage and industry demand for every tracked skill.</p>
      </div>

      <div style={{ marginBottom: 18 }}>
        <SearchInput value={search} onChange={setSearch} placeholder="Search skills…" />
      </div>

      {filtered.length === 0 ? (
        <EmptyState title="No skills match your search" />
      ) : (
        <div className="card">
          <DataTable columns={columns} rows={filtered} keyField="skill" />
        </div>
      )}
    </div>
  );
}
