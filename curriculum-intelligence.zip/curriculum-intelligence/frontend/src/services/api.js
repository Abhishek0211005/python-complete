import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 15000,
});

// Normalizes axios errors into a plain, UI-friendly shape.
function unwrap(promise) {
  return promise
    .then((res) => res.data)
    .catch((err) => {
      const detail =
        err.response?.data?.detail ||
        err.message ||
        "Something went wrong while talking to the server.";
      throw new Error(detail);
    });
}

export const api = {
  getDashboard: () => unwrap(apiClient.get("/api/dashboard")),

  getCurriculum: (programId) =>
    unwrap(apiClient.get("/api/curriculum", { params: { program_id: programId } })),
  getCourse: (courseId) => unwrap(apiClient.get(`/api/curriculum/${courseId}`)),

  getJobs: (params) => unwrap(apiClient.get("/api/jobs", { params })),
  getJob: (jobId) => unwrap(apiClient.get(`/api/jobs/${jobId}`)),

  getSkills: () => unwrap(apiClient.get("/api/skills")),
  getSkill: (skillName) => unwrap(apiClient.get(`/api/skills/${encodeURIComponent(skillName)}`)),

  getGraph: (params) => unwrap(apiClient.get("/api/graph", { params })),

  getAnalysisOptions: () => unwrap(apiClient.get("/api/analysis/options")),
  analyzeGap: (payload) => unwrap(apiClient.post("/api/analysis/gap", payload)),

  getRecommendations: (courseId, roleId) =>
    unwrap(apiClient.get("/api/recommendations", { params: { course_id: courseId, role_id: roleId } })),

  getEvaluation: () => unwrap(apiClient.get("/api/evaluation")),

  getHealth: () => unwrap(apiClient.get("/api/health")),
};
