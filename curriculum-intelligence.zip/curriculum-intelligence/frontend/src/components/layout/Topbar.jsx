import { useEffect, useState } from "react";
import { api } from "../../services/api.js";

const TITLES = {
  "/": ["Curriculum Intelligence Dashboard", "Track curriculum relevance, industry skill demand and academic alignment."],
  "/curriculum": ["Curriculum Explorer", "Browse programs, courses, modules and the skills extracted from them."],
  "/jobs": ["Industry Jobs", "Explore the job-description dataset and the skills required by each role."],
  "/skills": ["Skill Intelligence", "See curriculum coverage and industry demand for every tracked skill."],
  "/knowledge-graph": ["Knowledge Graph Explorer", "Visualize how curriculum and industry connect through shared skills."],
  "/skill-gap": ["Skill Gap Analysis", "Compare a course against a target job role to see alignment and gaps."],
  "/recommendations": ["Recommendations", "Explainable, priority-ranked suggestions for closing curriculum gaps."],
  "/reports": ["Reports & Evaluation", "Aggregate reporting and NLP extraction evaluation metrics."],
};

export default function Topbar({ pathname, onMenuClick }) {
  const [connected, setConnected] = useState(null);

  useEffect(() => {
    let cancelled = false;
    api
      .getHealth()
      .then((res) => !cancelled && setConnected(Boolean(res.neo4j_connected)))
      .catch(() => !cancelled && setConnected(false));
    return () => {
      cancelled = true;
    };
  }, [pathname]);

  const [title] = TITLES[pathname] || TITLES["/"];

  return (
    <header className="topbar">
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <button className="topbar-menu-btn" onClick={onMenuClick} aria-label="Open navigation">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M3 6h18M3 12h18M3 18h18" />
          </svg>
        </button>
        <p style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 15 }}>{title}</p>
      </div>
      <div className="topbar-status">
        <span className={`status-dot ${connected ? "status-dot-ok" : "status-dot-down"}`} />
        {connected === null ? "Checking connection…" : connected ? "Graph connected" : "Graph unavailable"}
      </div>
    </header>
  );
}
