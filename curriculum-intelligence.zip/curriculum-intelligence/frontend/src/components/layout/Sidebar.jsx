import { NavLink } from "react-router-dom";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard", icon: "grid" },
  { to: "/curriculum", label: "Curriculum", icon: "book" },
  { to: "/jobs", label: "Industry Jobs", icon: "briefcase" },
  { to: "/skills", label: "Skills", icon: "star" },
  { to: "/knowledge-graph", label: "Knowledge Graph", icon: "share" },
  { to: "/skill-gap", label: "Skill Gap Analysis", icon: "target" },
  { to: "/recommendations", label: "Recommendations", icon: "lightbulb" },
  { to: "/reports", label: "Reports", icon: "chart" },
];

const ICONS = {
  grid: (
    <path d="M4 4h6v6H4V4Zm10 0h6v6h-6V4ZM4 14h6v6H4v-6Zm10 0h6v6h-6v-6Z" />
  ),
  book: <path d="M5 4h9a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H5V4Zm0 14h12" />,
  briefcase: <path d="M4 8h16v11H4V8Zm4 0V6a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />,
  star: <path d="M12 3l2.6 5.6 6.1.6-4.6 4.1 1.4 6-5.5-3.2-5.5 3.2 1.4-6-4.6-4.1 6.1-.6L12 3Z" />,
  share: (
    <>
      <circle cx="6" cy="12" r="2.4" />
      <circle cx="17" cy="6" r="2.4" />
      <circle cx="17" cy="18" r="2.4" />
      <path d="M8.2 10.9 14.8 7.1M8.2 13.1l6.6 3.8" />
    </>
  ),
  target: (
    <>
      <circle cx="12" cy="12" r="8" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="12" cy="12" r="0.6" fill="currentColor" />
    </>
  ),
  lightbulb: <path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.6 10.8c.6.5.9 1 .9 1.7V17h5.4v-1.5c0-.7.3-1.2.9-1.7A6 6 0 0 0 12 3Z" />,
  chart: <path d="M5 19V9m6.5 10V5M18 19v-6" />,
};

function Icon({ name }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      {ICONS[name]}
    </svg>
  );
}

export default function Sidebar({ open, onNavigate }) {
  return (
    <aside className={`sidebar ${open ? "sidebar-open" : ""}`}>
      <div className="sidebar-brand">
        <div className="sidebar-mark">CI</div>
        <div>
          <p className="sidebar-brand-name">CurriculumIQ</p>
          <p className="sidebar-brand-sub">Curriculum Intelligence</p>
        </div>
      </div>
      <nav className="sidebar-nav">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === "/"}
            className={({ isActive }) => `sidebar-link ${isActive ? "sidebar-link-active" : ""}`}
            onClick={onNavigate}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
      <div className="sidebar-footer">
        <p className="text-muted" style={{ fontSize: 12 }}>MCA Minor Project</p>
        <p className="text-muted" style={{ fontSize: 12 }}>Knowledge Graph Edition</p>
      </div>
    </aside>
  );
}
