import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";

export default function ComparisonBarChart({ data, height = 260 }) {
  if (!data || data.length === 0) return null;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 4, right: 12, left: -18, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
        <XAxis dataKey="skill" tick={{ fontSize: 12, fill: "var(--color-text-secondary)" }} interval={0} angle={-28} textAnchor="end" height={70} />
        <YAxis tick={{ fontSize: 12, fill: "var(--color-text-secondary)" }} unit="%" />
        <Tooltip
          contentStyle={{ borderRadius: 10, border: "1px solid var(--color-border)", fontSize: 13 }}
          formatter={(value) => [`${value}%`, undefined]}
        />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Bar dataKey="industryDemand" name="Industry Demand" fill="#0f9c94" radius={[4, 4, 0, 0]} />
        <Bar dataKey="curriculumCoverage" name="Curriculum Coverage" fill="#3d3a9c" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
