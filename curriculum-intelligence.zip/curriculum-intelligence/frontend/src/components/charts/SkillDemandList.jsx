export default function SkillDemandList({ items, valueKey = "demand_percentage", nameKey = "skill" }) {
  if (!items || items.length === 0) return null;
  return (
    <div>
      {items.map((item) => (
        <div className="skill-bar-row" key={item[nameKey]}>
          <span style={{ fontWeight: 500 }}>{item[nameKey]}</span>
          <div className="skill-bar-track">
            <div className="skill-bar-fill" style={{ width: `${item[valueKey]}%` }} />
          </div>
          <span className="mono text-secondary" style={{ textAlign: "right" }}>
            {item[valueKey]}%
          </span>
        </div>
      ))}
    </div>
  );
}
