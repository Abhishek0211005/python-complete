/**
 * The recurring "instrument" motif used across the Dashboard and Skill
 * Gap pages: a single-color progress ring with the percentage rendered
 * in the mono face, evoking an analytics instrument panel rather than a
 * generic decorative donut chart.
 */
export default function AlignmentGauge({ value, label, size = 140, stroke = 12 }) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.max(0, Math.min(100, value ?? 0));
  const offset = circumference * (1 - clamped / 100);

  const color =
    clamped >= 70 ? "var(--color-success)" : clamped >= 40 ? "var(--color-warning)" : "var(--color-critical)";

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="var(--color-border)"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          style={{ transition: "stroke-dashoffset 0.6s ease" }}
        />
        <text
          x="50%"
          y="50%"
          textAnchor="middle"
          dominantBaseline="central"
          className="mono"
          style={{ fontSize: size * 0.19, fontWeight: 600, fill: "var(--color-text-primary)" }}
        >
          {clamped.toFixed(1)}%
        </text>
      </svg>
      {label && <p className="text-secondary" style={{ fontSize: 13, fontWeight: 500 }}>{label}</p>}
    </div>
  );
}
