import { useEffect, useRef, useState } from "react";
import { forceSimulation, forceLink, forceManyBody, forceCenter, forceCollide } from "d3-force";

const LABEL_COLORS = {
  Program: "#3d3a9c",
  Course: "#5b52d6",
  Module: "#8e87e0",
  Topic: "#b7b2ec",
  Skill: "#0f9c94",
  Industry: "#d97706",
  JobRole: "#dc2626",
  JobDescription: "#f0a3a3",
};

function colorFor(label) {
  return LABEL_COLORS[label] || "#9997ad";
}

export default function GraphCanvas({ graphData, onNodeClick, width = 800, height = 480 }) {
  const svgRef = useRef(null);
  const [nodes, setNodes] = useState([]);
  const [links, setLinks] = useState([]);
  const [transform, setTransform] = useState({ x: 0, y: 0, k: 1 });
  const dragState = useRef(null);

  useEffect(() => {
    if (!graphData || graphData.nodes.length === 0) {
      setNodes([]);
      setLinks([]);
      return;
    }
    const simNodes = graphData.nodes.map((n) => ({ ...n }));
    const nodeIndex = new Map(simNodes.map((n) => [n.id, n]));
    const simLinks = graphData.edges
      .filter((e) => nodeIndex.has(e.source) && nodeIndex.has(e.target))
      .map((e) => ({ ...e }));

    const simulation = forceSimulation(simNodes)
      .force("link", forceLink(simLinks).id((d) => d.id).distance(90).strength(0.6))
      .force("charge", forceManyBody().strength(-220))
      .force("center", forceCenter(width / 2, height / 2))
      .force("collide", forceCollide(28))
      .stop();

    for (let i = 0; i < 220; i++) simulation.tick();

    setNodes(simNodes);
    setLinks(simLinks);
  }, [graphData, width, height]);

  function handleWheel(e) {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.92 : 1.08;
    setTransform((t) => ({ ...t, k: Math.min(3, Math.max(0.4, t.k * delta)) }));
  }

  function handlePointerDown(e) {
    dragState.current = { startX: e.clientX, startY: e.clientY, origin: { ...transform } };
  }

  function handlePointerMove(e) {
    if (!dragState.current) return;
    const dx = e.clientX - dragState.current.startX;
    const dy = e.clientY - dragState.current.startY;
    setTransform({ ...dragState.current.origin, x: dragState.current.origin.x + dx, y: dragState.current.origin.y + dy });
  }

  function handlePointerUp() {
    dragState.current = null;
  }

  if (!graphData || nodes.length === 0) {
    return (
      <div className="empty-state">
        <p style={{ fontWeight: 600 }}>No graph data for this selection</p>
        <p>Try a different node type filter or root node.</p>
      </div>
    );
  }

  return (
    <div>
      <svg
        ref={svgRef}
        width="100%"
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        style={{ background: "var(--color-bg)", borderRadius: "var(--radius-md)", cursor: "grab" }}
        onWheel={handleWheel}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
      >
        <g transform={`translate(${transform.x} ${transform.y}) scale(${transform.k})`}>
          {links.map((link, i) => {
            const source = typeof link.source === "object" ? link.source : nodes.find((n) => n.id === link.source);
            const target = typeof link.target === "object" ? link.target : nodes.find((n) => n.id === link.target);
            if (!source || !target) return null;
            return (
              <line
                key={i}
                x1={source.x}
                y1={source.y}
                x2={target.x}
                y2={target.y}
                stroke="var(--color-border-strong)"
                strokeWidth={1.2}
              />
            );
          })}
          {nodes.map((node) => (
            <g
              key={node.id}
              transform={`translate(${node.x} ${node.y})`}
              onClick={(e) => {
                e.stopPropagation();
                onNodeClick && onNodeClick(node);
              }}
              style={{ cursor: "pointer" }}
            >
              <circle r={node.label === "Skill" ? 9 : 7} fill={colorFor(node.label)} stroke="white" strokeWidth={1.5} />
              <text
                x={12}
                y={4}
                fontSize={11}
                fontFamily="var(--font-body)"
                fill="var(--color-text-primary)"
                style={{ pointerEvents: "none" }}
              >
                {node.name}
              </text>
            </g>
          ))}
        </g>
      </svg>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 14, marginTop: 12 }}>
        {Object.entries(LABEL_COLORS).map(([label, color]) => (
          <div key={label} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}>
            <span style={{ width: 9, height: 9, borderRadius: "50%", background: color, display: "inline-block" }} />
            <span className="text-secondary">{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
