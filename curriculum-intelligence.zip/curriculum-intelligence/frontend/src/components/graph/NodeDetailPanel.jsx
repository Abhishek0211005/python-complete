import { useApiData } from "../../hooks/useApiData.js";
import { api } from "../../services/api.js";
import { LoadingState, ErrorState } from "../common/StatusStates.jsx";

export default function NodeDetailPanel({ node, onClose }) {
  const isSkill = node?.label === "Skill";
  const { data, loading, error } = useApiData(
    () => (isSkill ? api.getSkill(node.name) : Promise.resolve(null)),
    [node?.id],
    { skip: !isSkill }
  );

  if (!node) return null;

  return (
    <div className="card card-padded" style={{ minWidth: 260 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <p className="text-muted" style={{ fontSize: 11.5 }}>{node.label}</p>
          <p style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 16 }}>{node.name}</p>
        </div>
        <button className="btn btn-secondary" style={{ padding: "4px 10px", fontSize: 12 }} onClick={onClose}>✕</button>
      </div>

      {isSkill && (
        <div style={{ marginTop: 14 }}>
          {loading && <LoadingState label="Loading skill detail" />}
          {error && <ErrorState message={error} />}
          {data && (
            <>
              <p className="text-muted" style={{ fontSize: 11.5 }}>Category</p>
              <p style={{ fontSize: 13.5, marginBottom: 10 }}>{data.category}</p>

              <p className="text-muted" style={{ fontSize: 11.5 }}>Covered By</p>
              <p style={{ fontSize: 13.5, marginBottom: 10 }}>
                {data.covered_by_courses.length ? data.covered_by_courses.join(", ") : "Not covered by curriculum"}
              </p>

              <p className="text-muted" style={{ fontSize: 11.5 }}>Required By</p>
              <p style={{ fontSize: 13.5, marginBottom: 10 }}>
                {data.required_by_roles.length ? data.required_by_roles.join(", ") : "—"}
              </p>

              <p className="text-muted" style={{ fontSize: 11.5 }}>Relevant Jobs</p>
              <p className="mono" style={{ fontSize: 15, fontWeight: 600 }}>{data.job_count}</p>
            </>
          )}
        </div>
      )}

      {!isSkill && (
        <p className="text-secondary" style={{ fontSize: 13, marginTop: 12 }}>
          Click a Skill node to see its curriculum coverage and industry demand.
        </p>
      )}
    </div>
  );
}
