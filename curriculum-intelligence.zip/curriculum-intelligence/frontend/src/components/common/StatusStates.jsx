export function LoadingState({ label = "Loading data" }) {
  return (
    <div className="loading-state">
      <div className="spinner" />
      <p>{label}…</p>
    </div>
  );
}

export function EmptyState({ title = "Nothing here yet", hint }) {
  return (
    <div className="empty-state">
      <p style={{ fontWeight: 600, color: "var(--color-text-primary)" }}>{title}</p>
      {hint && <p>{hint}</p>}
    </div>
  );
}

export function ErrorState({ message, onRetry }) {
  return (
    <div className="error-state">
      <p style={{ fontWeight: 600 }}>Couldn't load this data</p>
      <p style={{ color: "var(--color-text-secondary)" }}>{message}</p>
      {onRetry && (
        <button className="btn btn-secondary" style={{ marginTop: 8 }} onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}
