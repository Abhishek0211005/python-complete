export default function KpiCard({ label, value, suffix = "", accent = "primary" }) {
  return (
    <div className="card card-padded">
      <p className="text-secondary" style={{ fontSize: 13, fontWeight: 500 }}>
        {label}
      </p>
      <p
        className="mono"
        style={{
          fontSize: 30,
          fontWeight: 600,
          marginTop: 8,
          color: accent === "teal" ? "var(--color-accent-teal)" : "var(--color-primary)",
        }}
      >
        {value}
        {suffix && <span style={{ fontSize: 16, marginLeft: 3 }}>{suffix}</span>}
      </p>
    </div>
  );
}
