const PRIORITY_CLASS = {
  HIGH: "badge-high",
  MEDIUM: "badge-medium",
  LOW: "badge-low",
};

export function PriorityBadge({ priority }) {
  return <span className={`badge ${PRIORITY_CLASS[priority] || "badge-neutral"}`}>{priority}</span>;
}

export function CoverageBadge({ covered }) {
  return (
    <span className={`badge ${covered ? "badge-covered" : "badge-missing"}`}>
      {covered ? "Covered" : "Missing"}
    </span>
  );
}

export function CategoryBadge({ category }) {
  return <span className="badge badge-neutral">{category}</span>;
}
