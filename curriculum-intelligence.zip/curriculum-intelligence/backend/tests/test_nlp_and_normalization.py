import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from app.utils.skill_normalizer import load_skill_dictionary
from app.services.nlp_service import extract_skills

SKILLS_PATH = Path(__file__).resolve().parent.parent.parent / "datasets" / "skill_dictionary" / "skills.json"


@pytest.fixture(scope="module")
def skill_dictionary():
    return load_skill_dictionary(SKILLS_PATH)


def test_alias_normalization_basic(skill_dictionary):
    assert skill_dictionary.normalize_alias("react") == "React.js"
    assert skill_dictionary.normalize_alias("reactjs") == "React.js"
    assert skill_dictionary.normalize_alias("react.js") == "React.js"
    assert skill_dictionary.normalize_alias("react js") == "React.js"


def test_alias_normalization_node_and_js(skill_dictionary):
    assert skill_dictionary.normalize_alias("node") == "Node.js"
    assert skill_dictionary.normalize_alias("nodejs") == "Node.js"
    assert skill_dictionary.normalize_alias("javascript") == "JavaScript"
    assert skill_dictionary.normalize_alias("js") == "JavaScript"


def test_unknown_alias_returns_none(skill_dictionary):
    assert skill_dictionary.normalize_alias("banana") is None


def test_extraction_does_not_false_positive_inside_dotted_skill(skill_dictionary):
    """
    Regression test: the alias 'js' must NOT be matched inside
    'react.js' or 'node.js' -- this was a real bug found during
    development (masking fix in skill_normalizer.match_text).
    """
    text = "Experience with React.js and Node.js required."
    result = extract_skills(text, skill_dictionary)
    assert "JavaScript" not in result.extracted_skills
    assert "React.js" in result.extracted_skills
    assert "Node.js" in result.extracted_skills


def test_extraction_matches_expected_skills(skill_dictionary):
    text = (
        "We are looking for a Full Stack Developer with experience in "
        "React.js, Node.js, MongoDB, Docker and AWS."
    )
    result = extract_skills(text, skill_dictionary)
    expected = {"React.js", "Node.js", "MongoDB", "Docker", "AWS"}
    assert expected.issubset(set(result.extracted_skills))


def test_extraction_ignores_ordinary_words(skill_dictionary):
    text = "The candidate should be a good communicator and team player."
    result = extract_skills(text, skill_dictionary)
    assert result.extracted_skills == []


def test_multiword_skill_extraction(skill_dictionary):
    text = "Solid understanding of Machine Learning and Deep Learning concepts."
    result = extract_skills(text, skill_dictionary)
    assert "Machine Learning" in result.extracted_skills
    assert "Deep Learning" in result.extracted_skills
