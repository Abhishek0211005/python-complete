import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.services import gap_service, graph_service, recommendation_service
from app.utils.skill_normalizer import load_skill_dictionary

SKILLS_PATH = Path(__file__).resolve().parent.parent.parent / "datasets" / "skill_dictionary" / "skills.json"

SAMPLE_ROLE_JOBS = [
    {"id": "JD-1", "title": "Full Stack Developer", "skills": ["React.js", "Docker", "AWS"]},
    {"id": "JD-2", "title": "Full Stack Developer", "skills": ["React.js", "Docker", "AWS"]},
    {"id": "JD-3", "title": "Full Stack Developer", "skills": ["React.js", "Docker"]},
    {"id": "JD-4", "title": "Full Stack Developer", "skills": ["React.js", "TypeScript"]},
    {"id": "JD-5", "title": "Full Stack Developer", "skills": ["React.js"]},
]


def test_priority_thresholds(monkeypatch):
    monkeypatch.setattr(graph_service, "get_course_skills", lambda course_id: ["React.js"])
    monkeypatch.setattr(graph_service, "get_jobs", lambda role_id=None, industry_id=None, search=None: SAMPLE_ROLE_JOBS)

    skill_dictionary = load_skill_dictionary(SKILLS_PATH)
    recs = recommendation_service.generate_recommendations(
        course_id="mca-web-development",
        role_id="full-stack-developer",
        course_name="Web Development",
        role_title="Full Stack Developer",
        skill_dictionary=skill_dictionary,
    )
    by_skill = {r["skill"]: r for r in recs}

    # Docker: 3/5 jobs = 60% -> MEDIUM
    assert by_skill["Docker"]["priority"] == "MEDIUM"
    # AWS: 2/5 jobs = 40% -> MEDIUM (boundary, >= 40)
    assert by_skill["AWS"]["priority"] == "MEDIUM"
    # TypeScript: 1/5 jobs = 20% -> LOW
    assert by_skill["TypeScript"]["priority"] == "LOW"

    # HIGH-priority items should always sort before MEDIUM/LOW
    priorities = [r["priority"] for r in recs]
    rank = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    ranks = [rank[p] for p in priorities]
    assert ranks == sorted(ranks)


def test_every_recommendation_explains_why(monkeypatch):
    monkeypatch.setattr(graph_service, "get_course_skills", lambda course_id: ["React.js"])
    monkeypatch.setattr(graph_service, "get_jobs", lambda role_id=None, industry_id=None, search=None: SAMPLE_ROLE_JOBS)

    skill_dictionary = load_skill_dictionary(SKILLS_PATH)
    recs = recommendation_service.generate_recommendations(
        course_id="mca-web-development",
        role_id="full-stack-developer",
        course_name="Web Development",
        role_title="Full Stack Developer",
        skill_dictionary=skill_dictionary,
    )
    for rec in recs:
        assert rec["reason"]
        assert rec["recommendation"]
        assert rec["skill"] in rec["reason"]
