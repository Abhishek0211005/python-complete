import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.services import gap_service, graph_service

SAMPLE_ROLE_JOBS = [
    {"id": "JD-1", "title": "Full Stack Developer", "skills": ["React.js", "Node.js", "MongoDB", "JavaScript", "Git", "REST API", "Docker", "AWS"]},
    {"id": "JD-2", "title": "Full Stack Developer", "skills": ["React.js", "Node.js", "JavaScript", "Git", "REST API", "TypeScript"]},
    {"id": "JD-3", "title": "Full Stack Developer", "skills": ["React.js", "Node.js", "MongoDB", "JavaScript", "Git", "REST API", "AWS"]},
]

CURRICULUM_SKILLS = ["React.js", "Node.js", "MongoDB", "JavaScript", "Git", "REST API"]


def test_basic_and_weighted_alignment(monkeypatch):
    monkeypatch.setattr(graph_service, "get_course_skills", lambda course_id: CURRICULUM_SKILLS)
    monkeypatch.setattr(graph_service, "get_jobs", lambda role_id=None, industry_id=None, search=None: SAMPLE_ROLE_JOBS)

    result = gap_service.analyze_gap(course_id="mca-web-development", role_id="full-stack-developer")

    # Industry skills across the 3 sample jobs: React.js, Node.js, MongoDB,
    # JavaScript, Git, REST API, Docker, AWS, TypeScript = 9 skills
    assert result["required_skill_count"] == 9
    assert set(result["covered_skills"]) == set(CURRICULUM_SKILLS)
    assert result["covered_skill_count"] == 6

    # basic alignment = 6/9 * 100 = 66.67
    assert result["basic_alignment_percentage"] == 66.67

    assert set(result["missing_skills"]) == {"Docker", "AWS", "TypeScript"}

    # weighted alignment should differ from basic since demand isn't uniform
    assert result["weighted_alignment_percentage"] != result["basic_alignment_percentage"]
    assert 0 <= result["weighted_alignment_percentage"] <= 100


def test_critical_skills_are_high_demand_missing_skills(monkeypatch):
    monkeypatch.setattr(graph_service, "get_course_skills", lambda course_id: CURRICULUM_SKILLS)
    monkeypatch.setattr(graph_service, "get_jobs", lambda role_id=None, industry_id=None, search=None: SAMPLE_ROLE_JOBS)

    result = gap_service.analyze_gap(course_id="mca-web-development", role_id="full-stack-developer")
    # AWS appears in 2/3 jobs (66.67%) -- below the 70% critical threshold,
    # so nothing should be flagged critical in this small sample; verify
    # the critical set is always a subset of missing skills regardless.
    assert set(result["critical_skills"]).issubset(set(result["missing_skills"]))
