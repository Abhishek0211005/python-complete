import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.services import networkx_service

SAMPLE_JOBS = [
    {"id": "JD-1", "title": "Full Stack Developer", "skills": ["React.js", "Docker", "AWS"]},
    {"id": "JD-2", "title": "Full Stack Developer", "skills": ["React.js", "Docker"]},
    {"id": "JD-3", "title": "Full Stack Developer", "skills": ["React.js"]},
    {"id": "JD-4", "title": "Full Stack Developer", "skills": []},
]


def test_skill_demand_percentages():
    demand = networkx_service.skill_demand(SAMPLE_JOBS)
    by_skill = {row["skill"]: row for row in demand}

    assert by_skill["React.js"]["jobs_requiring"] == 3
    assert by_skill["React.js"]["total_jobs"] == 4
    assert by_skill["React.js"]["demand_percentage"] == 75.0

    assert by_skill["Docker"]["demand_percentage"] == 50.0
    assert by_skill["AWS"]["demand_percentage"] == 25.0


def test_demand_sorted_descending():
    demand = networkx_service.skill_demand(SAMPLE_JOBS)
    percentages = [row["demand_percentage"] for row in demand]
    assert percentages == sorted(percentages, reverse=True)


def test_graph_statistics_shape():
    stats = networkx_service.graph_statistics(SAMPLE_JOBS)
    assert stats["job_nodes"] == 4
    assert stats["skill_nodes"] == 3
    assert stats["edges"] == 6  # 3 + 2 + 1 + 0
    assert stats["average_skills_per_job"] == 1.5


def test_empty_job_list_does_not_crash():
    assert networkx_service.skill_demand([]) == []
    stats = networkx_service.graph_statistics([])
    assert stats["job_nodes"] == 0
