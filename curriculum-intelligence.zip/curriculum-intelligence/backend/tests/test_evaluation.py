import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.services import evaluation_service
from app.utils.skill_normalizer import load_skill_dictionary

SKILLS_PATH = Path(__file__).resolve().parent.parent.parent / "datasets" / "skill_dictionary" / "skills.json"


def test_perfect_extraction_gives_perfect_scores():
    skill_dictionary = load_skill_dictionary(SKILLS_PATH)
    ground_truth = [
        {
            "job_id": "JD-TEST-1",
            "text": "Looking for a developer skilled in React.js, Node.js and Git.",
            "ground_truth_skills": ["React.js", "Node.js", "Git"],
        }
    ]
    result = evaluation_service.evaluate_extraction(ground_truth, skill_dictionary)
    assert result["precision"] == 1.0
    assert result["recall"] == 1.0
    assert result["f1_score"] == 1.0


def test_missed_skill_lowers_recall_not_precision():
    skill_dictionary = load_skill_dictionary(SKILLS_PATH)
    ground_truth = [
        {
            "job_id": "JD-TEST-2",
            # "Kubernetes" is deliberately absent from the text, so it can
            # never be extracted -> guaranteed false negative.
            "text": "Looking for a developer skilled in React.js and Node.js.",
            "ground_truth_skills": ["React.js", "Node.js", "Kubernetes"],
        }
    ]
    result = evaluation_service.evaluate_extraction(ground_truth, skill_dictionary)
    assert result["false_negatives"] == 1
    assert result["precision"] == 1.0
    assert result["recall"] < 1.0


def test_mapping_accuracy_is_perfect_for_the_shipped_dictionary():
    skill_dictionary = load_skill_dictionary(SKILLS_PATH)
    result = evaluation_service.evaluate_mapping_accuracy(skill_dictionary)
    # Every alias in our own controlled dictionary must normalize back to
    # its declared canonical skill -- this is what "mapping accuracy"
    # verifies (correctness of the normalization/canonicalization step).
    assert result["mapping_accuracy_percentage"] == 100.0
    assert result["failures"] == []
    assert result["total_alias_checks"] > 0
