"""
Neo4j driver lifecycle management.

The rest of the application should never import `neo4j` directly --
everything goes through get_driver()/run_query() here so connection
errors are handled in exactly one place and surfaced as a clean,
typed exception (Neo4jUnavailableError) rather than a raw stack trace
reaching the API layer.
"""
import logging
from typing import Any, Dict, List, Optional

from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable, AuthError

from app.config import get_settings

logger = logging.getLogger(__name__)


class Neo4jUnavailableError(Exception):
    """Raised whenever the Neo4j database cannot be reached or queried."""


_driver = None


def get_driver():
    global _driver
    if _driver is None:
        settings = get_settings()
        _driver = GraphDatabase.driver(
            settings.neo4j_uri,
            auth=(settings.neo4j_username, settings.neo4j_password),
        )
    return _driver


def close_driver():
    global _driver
    if _driver is not None:
        _driver.close()
        _driver = None


def check_connection() -> bool:
    try:
        driver = get_driver()
        driver.verify_connectivity()
        return True
    except Exception as exc:  # noqa: BLE001 - deliberately broad, we only report status
        logger.warning("Neo4j connectivity check failed: %s", exc)
        return False


def run_query(cypher: str, parameters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """
    Execute a single Cypher statement and return a list of plain dicts.
    Raises Neo4jUnavailableError on any connection/auth failure so the
    API layer can convert it into a clean HTTP 503 response.
    """
    parameters = parameters or {}
    try:
        driver = get_driver()
        with driver.session() as session:
            result = session.run(cypher, parameters)
            return [dict(record) for record in result]
    except (ServiceUnavailable, AuthError) as exc:
        raise Neo4jUnavailableError(f"Neo4j is unavailable: {exc}") from exc
    except Exception as exc:  # noqa: BLE001
        raise Neo4jUnavailableError(f"Neo4j query failed: {exc}") from exc


def run_write_query(cypher: str, parameters: Optional[Dict[str, Any]] = None) -> None:
    parameters = parameters or {}
    try:
        driver = get_driver()
        with driver.session() as session:
            session.execute_write(lambda tx: tx.run(cypher, parameters).consume())
    except (ServiceUnavailable, AuthError) as exc:
        raise Neo4jUnavailableError(f"Neo4j is unavailable: {exc}") from exc
    except Exception as exc:  # noqa: BLE001
        raise Neo4jUnavailableError(f"Neo4j query failed: {exc}") from exc
