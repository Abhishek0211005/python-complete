from typing import Any, Dict, List, Optional
from pydantic import BaseModel


class GapAnalysisRequest(BaseModel):
    program_id: Optional[str] = None
    course_id: str
    role_id: str


class GapAnalysisResponse(BaseModel):
    course_id: str
    role_id: str
    curriculum_skills: List[str]
    industry_skills: List[str]
    covered_skills: List[str]
    missing_skills: List[str]
    critical_skills: List[str]
    basic_alignment_percentage: float
    weighted_alignment_percentage: float
    skill_demand: Dict[str, Any]
    required_skill_count: int
    covered_skill_count: int


class RecommendationOut(BaseModel):
    skill: str
    category: str
    industry_demand_percentage: float
    jobs_requiring: int
    total_relevant_jobs: int
    curriculum_coverage: str
    priority: str
    reason: str
    recommendation: str
