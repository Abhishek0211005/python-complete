from typing import List, Optional
from pydantic import BaseModel


class JobRoleOut(BaseModel):
    id: str
    title: str
    job_count: int


class JobOut(BaseModel):
    id: str
    title: str
    company: Optional[str] = None
    industry: Optional[str] = None
    location: Optional[str] = None
    description: Optional[str] = None
    skills: List[str] = []
    role_id: Optional[str] = None
