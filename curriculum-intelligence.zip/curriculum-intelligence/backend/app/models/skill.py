from typing import List
from pydantic import BaseModel


class SkillOverviewOut(BaseModel):
    skill: str
    category: str
    covered_by_courses: List[str] = []
    required_by_roles: List[str] = []
    job_count: int = 0


class SkillDetailOut(SkillOverviewOut):
    pass
