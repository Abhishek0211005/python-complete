from typing import List, Optional
from pydantic import BaseModel


class ProgramOut(BaseModel):
    id: str
    name: str


class CourseOut(BaseModel):
    id: str
    name: str
    program: Optional[str] = None


class TopicOut(BaseModel):
    id: str
    name: str
    description: str
    skills: List[str] = []


class ModuleOut(BaseModel):
    id: str
    name: str
    topics: List[TopicOut] = []


class CourseDetailOut(BaseModel):
    id: str
    name: str
    modules: List[ModuleOut] = []
    skills: List[str] = []
