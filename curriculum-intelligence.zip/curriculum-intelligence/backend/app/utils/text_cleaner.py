"""
Basic text cleaning applied before tokenization.

Kept intentionally simple and explainable: strip HTML-ish artifacts,
normalize whitespace, and lowercase. We deliberately do NOT strip
characters like '.', '#', '+' at this stage because they are meaningful
inside skill names (React.js, C++, C#) -- the skill matcher works on
the cleaned-but-not-overly-aggressive text.
"""
import re

_WHITESPACE_RE = re.compile(r"\s+")
_HTML_TAG_RE = re.compile(r"<[^>]+>")


def clean_text(raw_text: str) -> str:
    if not raw_text:
        return ""
    text = _HTML_TAG_RE.sub(" ", raw_text)
    text = text.replace("\n", " ").replace("\r", " ").replace("\t", " ")
    text = _WHITESPACE_RE.sub(" ", text)
    return text.strip()
