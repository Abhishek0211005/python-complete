"""
Small helpers for turning human-readable names into stable node ids,
and for loading the JSON seed datasets used by the ingestion routines.
"""
import json
import re
from pathlib import Path
from typing import Any


def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")


def load_json(path: Path) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
