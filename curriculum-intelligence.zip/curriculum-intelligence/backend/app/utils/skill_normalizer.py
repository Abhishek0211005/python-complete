"""
Skill normalization.

The skill dictionary (datasets/skill_dictionary/skills.json) is the
single source of truth for what counts as a "skill" and what its
canonical name is. This module builds a fast alias -> canonical lookup
and exposes a regex-based phrase matcher that is safe for skill names
containing punctuation (React.js, Node.js, C++, C#, CI/CD, REST API).

Why regex phrase matching instead of pure token-by-token comparison?
Punctuation-heavy skill names get mangled by generic tokenizers (e.g.
"React.js" tokenizes into "React", ".", "js"). Matching the *cleaned,
lowercased raw text* against escaped alias patterns keeps these names
intact, while the NLTK pipeline (tokenize/stopword-removal/lemmatize)
still runs and is used for plain single/multi-word skill candidates
and for demonstrating the classic NLP pipeline stages.
"""
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple


@dataclass(frozen=True)
class SkillEntry:
    canonical: str
    category: str
    aliases: Tuple[str, ...]


class SkillDictionary:
    """Loads the skill taxonomy and provides normalization utilities."""

    def __init__(self, entries: List[SkillEntry]):
        self.entries = entries
        self._alias_to_canonical: Dict[str, str] = {}
        self._canonical_to_category: Dict[str, str] = {}
        for entry in entries:
            self._canonical_to_category[entry.canonical] = entry.category
            # canonical itself is always a valid alias of itself
            all_aliases = set(a.lower().strip() for a in entry.aliases) | {entry.canonical.lower()}
            for alias in all_aliases:
                self._alias_to_canonical[alias] = entry.canonical

        # Sort aliases by token length (word count) then char length,
        # descending, so multi-word aliases are matched before shorter
        # substrings of themselves (e.g. "machine learning" before "machine").
        self._sorted_aliases = sorted(
            self._alias_to_canonical.keys(),
            key=lambda a: (len(a.split()), len(a)),
            reverse=True,
        )
        self._compiled_patterns: List[Tuple[re.Pattern, str]] = []
        for alias in self._sorted_aliases:
            canonical = self._alias_to_canonical[alias]
            pattern = re.compile(r"(?<![a-z0-9])" + re.escape(alias) + r"(?![a-z0-9])")
            self._compiled_patterns.append((pattern, canonical))

    @property
    def all_canonical_skills(self) -> List[str]:
        return list(self._canonical_to_category.keys())

    def category_of(self, canonical: str) -> str:
        return self._canonical_to_category.get(canonical, "Uncategorized")

    def normalize_alias(self, token: str) -> str | None:
        return self._alias_to_canonical.get(token.lower().strip())

    def match_text(self, cleaned_lowercase_text: str) -> List[str]:
        """
        Regex-based phrase match against the full alias list.
        Returns canonical skill names found in the text (deduplicated,
        insertion-ordered). Longer/multi-word aliases are matched first,
        and each match is masked out of the working text before shorter
        aliases are checked -- this prevents a short/ambiguous alias
        (e.g. "js") from being wrongly matched *inside* a longer skill
        name that already contains it (e.g. "react.js", "node.js").
        """
        found: List[str] = []
        seen = set()
        working_text = cleaned_lowercase_text
        for pattern, canonical in self._compiled_patterns:
            if canonical in seen:
                continue
            match = pattern.search(working_text)
            if match:
                found.append(canonical)
                seen.add(canonical)
                start, end = match.span()
                working_text = working_text[:start] + (" " * (end - start)) + working_text[end:]
        return found


def load_skill_dictionary(path: Path) -> SkillDictionary:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    entries = [
        SkillEntry(
            canonical=item["canonical_skill"],
            category=item.get("category", "Uncategorized"),
            aliases=tuple(item.get("aliases", [])),
        )
        for item in raw
    ]
    return SkillDictionary(entries)
