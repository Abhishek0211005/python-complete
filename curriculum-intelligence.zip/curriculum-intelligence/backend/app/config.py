"""
Central application configuration.

All environment-dependent values (Neo4j credentials, CORS origins,
dataset paths) are read from environment variables / a .env file so
nothing sensitive is hard-coded in source control.
"""
from pathlib import Path
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_ROOT = Path(__file__).resolve().parent.parent  # backend/


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Neo4j
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_username: str = "neo4j"
    neo4j_password: str = "neo4j"

    # CORS
    allowed_origins: str = "http://localhost:5173,http://127.0.0.1:5173"

    # Dataset paths (relative to backend/ unless absolute)
    curriculum_data_path: str = "../datasets/curriculum/curriculum.json"
    jobs_data_path: str = "../datasets/job_descriptions/jobs.json"
    skills_data_path: str = "../datasets/skill_dictionary/skills.json"
    ground_truth_data_path: str = "../datasets/ground_truth/labeled_jobs.json"

    @property
    def allowed_origins_list(self) -> list[str]:
        return [o.strip() for o in self.allowed_origins.split(",") if o.strip()]

    def resolve_path(self, relative_or_absolute: str) -> Path:
        p = Path(relative_or_absolute)
        if p.is_absolute():
            return p
        return (BACKEND_ROOT / p).resolve()


@lru_cache
def get_settings() -> Settings:
    return Settings()
