from fastapi import APIRouter, HTTPException, Query

from app.services import graph_service, recommendation_service
from app.services.skill_service import get_skill_dictionary

router = APIRouter(prefix="/api/recommendations", tags=["Recommendations"])


@router.get("")
def get_recommendations(course_id: str = Query(...), role_id: str = Query(...)):
    course = graph_service.get_course_detail(course_id)
    if course is None:
        raise HTTPException(status_code=404, detail=f"Course '{course_id}' was not found.")

    roles = {r["id"]: r for r in graph_service.get_job_roles()}
    role = roles.get(role_id)
    if role is None:
        raise HTTPException(status_code=404, detail=f"Job role '{role_id}' was not found.")

    recommendations = recommendation_service.generate_recommendations(
        course_id=course_id,
        role_id=role_id,
        course_name=course["name"],
        role_title=role["title"],
        skill_dictionary=get_skill_dictionary(),
    )
    return {"course": course["name"], "role": role["title"], "recommendations": recommendations}
