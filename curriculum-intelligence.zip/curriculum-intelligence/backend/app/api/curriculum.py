from typing import Optional

from fastapi import APIRouter, HTTPException, Query

from app.services import graph_service

router = APIRouter(prefix="/api/curriculum", tags=["Curriculum"])


@router.get("")
def list_curriculum(program_id: Optional[str] = Query(default=None)):
    programs = graph_service.get_programs()
    courses = graph_service.get_courses(program_id)
    return {"programs": programs, "courses": courses}


@router.get("/{course_id}")
def get_course(course_id: str):
    course = graph_service.get_course_detail(course_id)
    if course is None:
        raise HTTPException(status_code=404, detail=f"Course '{course_id}' was not found.")
    return course
