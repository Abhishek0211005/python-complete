from typing import Optional

from fastapi import APIRouter, Query

from app.services import graph_service

router = APIRouter(prefix="/api/graph", tags=["Knowledge Graph"])


@router.get("")
def get_graph(
    node_type: Optional[str] = Query(default=None, description="Program|Course|Module|Topic|Skill|Industry|JobRole|JobDescription"),
    root_id: Optional[str] = Query(default=None, description="Center the subgraph on this node id"),
    limit: int = Query(default=120, le=500),
):
    return graph_service.get_subgraph(node_type=node_type, root_id=root_id, limit=limit)


@router.get("/program/{program_id}")
def get_program_subgraph(program_id: str, limit: int = 150):
    return graph_service.get_subgraph(root_id=program_id, limit=limit)


@router.get("/job-role/{role_id}")
def get_job_role_subgraph(role_id: str, limit: int = 150):
    return graph_service.get_subgraph(root_id=role_id, limit=limit)
