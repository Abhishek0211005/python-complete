from fastapi import APIRouter

from app.models.analysis import GapAnalysisRequest
from app.services import gap_service, graph_service

router = APIRouter(prefix="/api/analysis", tags=["Analysis"])


@router.get("/options")
def get_analysis_options():
    """Populates the Program / Course / Job Role dropdowns on the Skill Gap page."""
    return {
        "programs": graph_service.get_programs(),
        "courses": graph_service.get_courses(),
        "roles": graph_service.get_job_roles(),
    }


@router.post("/gap")
def analyze_gap(request: GapAnalysisRequest):
    return gap_service.analyze_gap(course_id=request.course_id, role_id=request.role_id)
