from fastapi import APIRouter

from app.services import evaluation_service
from app.services.skill_service import get_ground_truth_data, get_skill_dictionary

router = APIRouter(prefix="/api/evaluation", tags=["Evaluation"])


@router.get("")
def get_evaluation():
    return evaluation_service.run_full_evaluation(get_ground_truth_data(), get_skill_dictionary())
