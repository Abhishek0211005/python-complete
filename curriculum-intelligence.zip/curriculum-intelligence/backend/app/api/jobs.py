from typing import Optional

from fastapi import APIRouter, HTTPException, Query

from app.services import graph_service

router = APIRouter(prefix="/api/jobs", tags=["Industry Jobs"])


@router.get("")
def list_jobs(
    role_id: Optional[str] = Query(default=None),
    industry_id: Optional[str] = Query(default=None),
    search: Optional[str] = Query(default=None),
):
    jobs = graph_service.get_jobs(role_id=role_id, industry_id=industry_id, search=search)
    roles = graph_service.get_job_roles()
    return {"jobs": jobs, "roles": roles}


@router.get("/{job_id}")
def get_job(job_id: str):
    job = graph_service.get_job_detail(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' was not found.")
    return job
