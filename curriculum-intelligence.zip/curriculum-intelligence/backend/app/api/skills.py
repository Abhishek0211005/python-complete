from fastapi import APIRouter, HTTPException

from app.services import graph_service

router = APIRouter(prefix="/api/skills", tags=["Skills"])


@router.get("")
def list_skills():
    return {"skills": graph_service.get_all_skills_overview()}


@router.get("/{skill_name}")
def get_skill(skill_name: str):
    skill = graph_service.get_skill_detail(skill_name)
    if skill is None:
        raise HTTPException(status_code=404, detail=f"Skill '{skill_name}' was not found.")
    return skill
