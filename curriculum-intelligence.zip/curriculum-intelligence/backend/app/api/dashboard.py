from fastapi import APIRouter

from app.services import graph_service, networkx_service, recommendation_service
from app.services.skill_service import get_skill_dictionary

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])


@router.get("")
def get_dashboard():
    counts = graph_service.get_total_counts()
    all_jobs = graph_service.get_jobs()
    top_skills = networkx_service.top_skills(all_jobs, top_n=8)
    stats = networkx_service.graph_statistics(all_jobs)

    # Overall alignment: across every course, how well curriculum skills
    # cover the union of industry-required skills (unweighted, dataset-wide).
    all_industry_skills = {row["skill"] for row in top_skills} if top_skills else set()
    # broaden to the full demand list, not just top 8, for the alignment number
    full_demand = networkx_service.skill_demand(all_jobs)
    all_industry_skills = {row["skill"] for row in full_demand}

    courses = graph_service.get_courses()
    all_curriculum_skills = set()
    for course in courses:
        all_curriculum_skills.update(graph_service.get_course_skills(course["id"]))

    covered = all_curriculum_skills & all_industry_skills
    overall_alignment = (
        round(100.0 * len(covered) / len(all_industry_skills), 2) if all_industry_skills else 0.0
    )

    missing_high_priority = []
    demand_by_skill = {row["skill"]: row for row in full_demand}
    for skill in sorted(all_industry_skills - all_curriculum_skills,
                         key=lambda s: demand_by_skill[s]["demand_percentage"], reverse=True)[:6]:
        demand_pct = demand_by_skill[skill]["demand_percentage"]
        priority = "HIGH" if demand_pct >= 70 else ("MEDIUM" if demand_pct >= 40 else "LOW")
        missing_high_priority.append({"skill": skill, "priority": priority, "demand_percentage": demand_pct})

    return {
        "total_courses": len(courses),
        "total_skills": counts.get("skill_count", 0),
        "total_jobs_analyzed": counts.get("job_count", 0),
        "overall_alignment_percentage": overall_alignment,
        "top_industry_skills": top_skills,
        "covered_curriculum_skills": sorted(all_curriculum_skills),
        "critical_skill_gaps": missing_high_priority,
        "graph_statistics": stats,
    }
