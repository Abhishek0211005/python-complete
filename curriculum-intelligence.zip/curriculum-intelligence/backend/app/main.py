"""
FastAPI application entrypoint.

Route handlers stay thin (see app/api/*.py) -- all business logic lives
in app/services/*.py. This file only wires the app together: CORS,
router registration, startup ingestion, and a global handler that turns
a Neo4j outage into a clean 503 JSON response instead of a stack trace.
"""
import logging

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import get_settings
from app.database.neo4j import Neo4jUnavailableError, check_connection, close_driver
from app.api import analysis, curriculum, dashboard, evaluation, graph, jobs, recommendations, skills
from app.services.skill_service import ingest_all_data

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("curriculum_intelligence")

settings = get_settings()

app = FastAPI(
    title="Curriculum Intelligence API",
    description="Knowledge Graph-Based Curriculum Intelligence for Industry Skill Alignment",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Neo4jUnavailableError)
async def neo4j_unavailable_handler(request: Request, exc: Neo4jUnavailableError):
    logger.error("Neo4j unavailable: %s", exc)
    return JSONResponse(
        status_code=503,
        content={
            "detail": (
                "The knowledge graph database is currently unavailable. "
                "Please verify Neo4j is running and the credentials in .env are correct."
            )
        },
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled error while processing %s %s", request.method, request.url)
    return JSONResponse(status_code=500, content={"detail": "An unexpected server error occurred."})


app.include_router(dashboard.router)
app.include_router(curriculum.router)
app.include_router(jobs.router)
app.include_router(skills.router)
app.include_router(graph.router)
app.include_router(analysis.router)
app.include_router(recommendations.router)
app.include_router(evaluation.router)


@app.get("/api/health")
def health_check():
    return {"status": "ok", "neo4j_connected": check_connection()}


@app.post("/api/admin/reingest")
def reingest():
    """
    Wipes and rebuilds the graph from the JSON datasets on disk.
    This is the one manual step needed the first time you point the
    app at a fresh Neo4j instance (see README "Neo4j Setup").
    """
    stats = ingest_all_data()
    return {"status": "ingested", "stats": stats}


@app.on_event("startup")
def on_startup():
    if check_connection():
        logger.info("Neo4j connection verified.")
    else:
        logger.warning(
            "Neo4j is not reachable at startup. The API will still run, but graph-dependent "
            "endpoints will return 503 until Neo4j is available and POST /api/admin/reingest is called."
        )


@app.on_event("shutdown")
def on_shutdown():
    close_driver()
