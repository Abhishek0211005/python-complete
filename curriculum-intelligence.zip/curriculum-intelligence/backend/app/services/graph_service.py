"""
Graph service -- every Cypher statement in the application lives here.

Responsibilities:
  1. Schema setup (constraints/indexes).
  2. Ingestion: turn curriculum.json / jobs.json into graph nodes and
     relationships, running each description through the NLP pipeline
     to discover Skill nodes and canonical-linking them.
  3. Read queries used by the API layer (curriculum tree, job listings,
     skill detail, subgraphs for the Knowledge Graph explorer).

Neo4j is used as a genuine relationship store here -- traversals like
"skills covered by a course" or "skills required across a job role's
postings" are expressed as graph patterns (MATCH ... -[:HAS_MODULE]->
... -[:COVERS]->), not as flat table scans.
"""
from typing import Any, Dict, List

from app.database.neo4j import run_query, run_write_query
from app.services.nlp_service import extract_skills
from app.utils.file_parser import slugify
from app.utils.skill_normalizer import SkillDictionary


# ---------------------------------------------------------------------------
# Schema setup
# ---------------------------------------------------------------------------

CONSTRAINTS = [
    "CREATE CONSTRAINT skill_canonical_unique IF NOT EXISTS FOR (s:Skill) REQUIRE s.canonical_name IS UNIQUE",
    "CREATE CONSTRAINT program_id_unique IF NOT EXISTS FOR (p:Program) REQUIRE p.id IS UNIQUE",
    "CREATE CONSTRAINT course_id_unique IF NOT EXISTS FOR (c:Course) REQUIRE c.id IS UNIQUE",
    "CREATE CONSTRAINT module_id_unique IF NOT EXISTS FOR (m:Module) REQUIRE m.id IS UNIQUE",
    "CREATE CONSTRAINT topic_id_unique IF NOT EXISTS FOR (t:Topic) REQUIRE t.id IS UNIQUE",
    "CREATE CONSTRAINT industry_id_unique IF NOT EXISTS FOR (i:Industry) REQUIRE i.id IS UNIQUE",
    "CREATE CONSTRAINT jobrole_id_unique IF NOT EXISTS FOR (r:JobRole) REQUIRE r.id IS UNIQUE",
    "CREATE CONSTRAINT jobdesc_id_unique IF NOT EXISTS FOR (j:JobDescription) REQUIRE j.id IS UNIQUE",
    "CREATE INDEX skill_category_idx IF NOT EXISTS FOR (s:Skill) ON (s.category)",
]


def setup_schema() -> None:
    for statement in CONSTRAINTS:
        run_write_query(statement)


def clear_graph() -> None:
    """Wipe all nodes/relationships -- used before a fresh ingestion run."""
    run_write_query("MATCH (n) DETACH DELETE n")


# ---------------------------------------------------------------------------
# Ingestion
# ---------------------------------------------------------------------------

def _merge_skill(canonical: str, category: str) -> None:
    run_write_query(
        "MERGE (s:Skill {canonical_name: $name}) SET s.category = $category",
        {"name": canonical, "category": category},
    )


def ingest_curriculum(curriculum_data: Dict[str, Any], skill_dictionary: SkillDictionary) -> Dict[str, int]:
    program_name = curriculum_data["program"]
    program_id = slugify(program_name)
    run_write_query(
        "MERGE (p:Program {id: $id}) SET p.name = $name",
        {"id": program_id, "name": program_name},
    )

    stats = {"courses": 0, "modules": 0, "topics": 0, "skill_links": 0}

    for course in curriculum_data.get("courses", []):
        course_name = course["course"]
        course_id = slugify(f"{program_id}-{course_name}")
        run_write_query(
            """
            MATCH (p:Program {id: $program_id})
            MERGE (c:Course {id: $course_id})
            SET c.name = $course_name
            MERGE (p)-[:HAS_COURSE]->(c)
            """,
            {"program_id": program_id, "course_id": course_id, "course_name": course_name},
        )
        stats["courses"] += 1

        for module in course.get("modules", []):
            module_name = module["module"]
            module_id = slugify(f"{course_id}-{module_name}")
            run_write_query(
                """
                MATCH (c:Course {id: $course_id})
                MERGE (m:Module {id: $module_id})
                SET m.name = $module_name
                MERGE (c)-[:HAS_MODULE]->(m)
                """,
                {"course_id": course_id, "module_id": module_id, "module_name": module_name},
            )
            stats["modules"] += 1

            for topic in module.get("topics", []):
                topic_name = topic["topic"]
                description = topic.get("description", "")
                topic_id = slugify(f"{module_id}-{topic_name}")
                run_write_query(
                    """
                    MATCH (m:Module {id: $module_id})
                    MERGE (t:Topic {id: $topic_id})
                    SET t.name = $topic_name, t.description = $description
                    MERGE (m)-[:HAS_TOPIC]->(t)
                    """,
                    {
                        "module_id": module_id,
                        "topic_id": topic_id,
                        "topic_name": topic_name,
                        "description": description,
                    },
                )
                stats["topics"] += 1

                result = extract_skills(description, skill_dictionary)
                for skill in result.extracted_skills:
                    category = skill_dictionary.category_of(skill)
                    _merge_skill(skill, category)
                    run_write_query(
                        """
                        MATCH (t:Topic {id: $topic_id})
                        MATCH (s:Skill {canonical_name: $skill})
                        MERGE (t)-[:COVERS]->(s)
                        """,
                        {"topic_id": topic_id, "skill": skill},
                    )
                    stats["skill_links"] += 1

    return stats


def ingest_jobs(jobs_data: List[Dict[str, Any]], skill_dictionary: SkillDictionary) -> Dict[str, int]:
    stats = {"industries": 0, "roles": 0, "job_descriptions": 0, "skill_links": 0}
    seen_industries, seen_roles = set(), set()

    for job in jobs_data:
        industry_name = job.get("industry", "General")
        role_title = job["job_title"]
        industry_id = slugify(industry_name)
        role_id = slugify(role_title)
        job_id = job["job_id"]

        run_write_query(
            "MERGE (i:Industry {id: $id}) SET i.name = $name",
            {"id": industry_id, "name": industry_name},
        )
        if industry_id not in seen_industries:
            stats["industries"] += 1
            seen_industries.add(industry_id)

        run_write_query(
            """
            MATCH (i:Industry {id: $industry_id})
            MERGE (r:JobRole {id: $role_id})
            SET r.title = $role_title
            MERGE (i)-[:HAS_ROLE]->(r)
            """,
            {"industry_id": industry_id, "role_id": role_id, "role_title": role_title},
        )
        if role_id not in seen_roles:
            stats["roles"] += 1
            seen_roles.add(role_id)

        run_write_query(
            """
            MATCH (r:JobRole {id: $role_id})
            MERGE (j:JobDescription {id: $job_id})
            SET j.title = $role_title, j.company = $company, j.industry = $industry_name,
                j.location = $location, j.source = $source, j.raw_text = $raw_text
            MERGE (r)-[:HAS_DESCRIPTION]->(j)
            """,
            {
                "role_id": role_id,
                "job_id": job_id,
                "role_title": role_title,
                "company": job.get("company", ""),
                "industry_name": industry_name,
                "location": job.get("location", ""),
                "source": job.get("source", ""),
                "raw_text": job.get("description", ""),
            },
        )
        stats["job_descriptions"] += 1

        result = extract_skills(job.get("description", ""), skill_dictionary)
        for skill in result.extracted_skills:
            category = skill_dictionary.category_of(skill)
            _merge_skill(skill, category)
            run_write_query(
                """
                MATCH (j:JobDescription {id: $job_id})
                MATCH (s:Skill {canonical_name: $skill})
                MERGE (j)-[:REQUIRES]->(s)
                """,
                {"job_id": job_id, "skill": skill},
            )
            stats["skill_links"] += 1

    return stats


# ---------------------------------------------------------------------------
# Read queries
# ---------------------------------------------------------------------------

def get_programs() -> List[Dict[str, Any]]:
    return run_query("MATCH (p:Program) RETURN p.id AS id, p.name AS name ORDER BY p.name")


def get_courses(program_id: str = None) -> List[Dict[str, Any]]:
    if program_id:
        return run_query(
            """
            MATCH (p:Program {id: $program_id})-[:HAS_COURSE]->(c:Course)
            RETURN c.id AS id, c.name AS name, p.name AS program
            ORDER BY c.name
            """,
            {"program_id": program_id},
        )
    return run_query(
        "MATCH (p:Program)-[:HAS_COURSE]->(c:Course) RETURN c.id AS id, c.name AS name, p.name AS program ORDER BY c.name"
    )


def get_course_detail(course_id: str) -> Dict[str, Any]:
    course_rows = run_query("MATCH (c:Course {id: $id}) RETURN c.id AS id, c.name AS name", {"id": course_id})
    if not course_rows:
        return None
    course = course_rows[0]

    modules = run_query(
        """
        MATCH (c:Course {id: $id})-[:HAS_MODULE]->(m:Module)
        OPTIONAL MATCH (m)-[:HAS_TOPIC]->(t:Topic)
        OPTIONAL MATCH (t)-[:COVERS]->(s:Skill)
        RETURN m.id AS module_id, m.name AS module_name,
               t.id AS topic_id, t.name AS topic_name, t.description AS description,
               collect(DISTINCT s.canonical_name) AS skills
        ORDER BY module_name, topic_name
        """,
        {"id": course_id},
    )

    module_map: Dict[str, Dict[str, Any]] = {}
    all_skills = set()
    for row in modules:
        m_id = row["module_id"]
        if m_id not in module_map:
            module_map[m_id] = {"id": m_id, "name": row["module_name"], "topics": []}
        if row["topic_id"]:
            skills = [s for s in row["skills"] if s]
            all_skills.update(skills)
            module_map[m_id]["topics"].append({
                "id": row["topic_id"],
                "name": row["topic_name"],
                "description": row["description"],
                "skills": skills,
            })

    course["modules"] = list(module_map.values())
    course["skills"] = sorted(all_skills)
    return course


def get_course_skills(course_id: str) -> List[str]:
    rows = run_query(
        """
        MATCH (c:Course {id: $id})-[:HAS_MODULE]->(:Module)-[:HAS_TOPIC]->(:Topic)-[:COVERS]->(s:Skill)
        RETURN DISTINCT s.canonical_name AS skill
        """,
        {"id": course_id},
    )
    return sorted(r["skill"] for r in rows)


def get_job_roles() -> List[Dict[str, Any]]:
    return run_query(
        """
        MATCH (r:JobRole)-[:HAS_DESCRIPTION]->(j:JobDescription)
        RETURN r.id AS id, r.title AS title, count(j) AS job_count
        ORDER BY r.title
        """
    )


def get_jobs(role_id: str = None, industry_id: str = None, search: str = None) -> List[Dict[str, Any]]:
    filters = []
    params: Dict[str, Any] = {}
    if role_id:
        filters.append("r.id = $role_id")
        params["role_id"] = role_id
    if industry_id:
        filters.append("i.id = $industry_id")
        params["industry_id"] = industry_id
    if search:
        filters.append("(toLower(j.title) CONTAINS toLower($search) OR toLower(j.company) CONTAINS toLower($search))")
        params["search"] = search

    where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""
    query = f"""
        MATCH (i:Industry)-[:HAS_ROLE]->(r:JobRole)-[:HAS_DESCRIPTION]->(j:JobDescription)
        {where_clause}
        OPTIONAL MATCH (j)-[:REQUIRES]->(s:Skill)
        RETURN j.id AS id, j.title AS title, j.company AS company, j.industry AS industry,
               j.location AS location, j.raw_text AS description, r.id AS role_id,
               collect(DISTINCT s.canonical_name) AS skills
        ORDER BY j.id
    """
    return run_query(query, params)


def get_job_detail(job_id: str) -> Dict[str, Any]:
    rows = run_query(
        """
        MATCH (j:JobDescription {id: $id})
        OPTIONAL MATCH (j)-[:REQUIRES]->(s:Skill)
        RETURN j.id AS id, j.title AS title, j.company AS company, j.industry AS industry,
               j.location AS location, j.raw_text AS description,
               collect(DISTINCT s.canonical_name) AS skills
        """,
        {"id": job_id},
    )
    return rows[0] if rows else None


def get_required_skills_for_role(role_id: str) -> List[Dict[str, Any]]:
    """For each skill required anywhere in this role's postings, how many
    (and what fraction) of that role's job descriptions require it."""
    return run_query(
        """
        MATCH (r:JobRole {id: $role_id})-[:HAS_DESCRIPTION]->(j:JobDescription)
        WITH r, count(DISTINCT j) AS total_jobs
        MATCH (r)-[:HAS_DESCRIPTION]->(j2:JobDescription)-[:REQUIRES]->(s:Skill)
        WITH s.canonical_name AS skill, count(DISTINCT j2) AS jobs_requiring, total_jobs
        RETURN skill, jobs_requiring, total_jobs,
               round(100.0 * jobs_requiring / total_jobs, 2) AS demand_percentage
        ORDER BY demand_percentage DESC
        """,
        {"role_id": role_id},
    )


def get_all_skills_overview() -> List[Dict[str, Any]]:
    return run_query(
        """
        MATCH (s:Skill)
        OPTIONAL MATCH (s)<-[:COVERS]-(:Topic)<-[:HAS_TOPIC]-(:Module)<-[:HAS_MODULE]-(c:Course)
        OPTIONAL MATCH (s)<-[:REQUIRES]-(j:JobDescription)<-[:HAS_DESCRIPTION]-(r:JobRole)
        RETURN s.canonical_name AS skill, s.category AS category,
               collect(DISTINCT c.name) AS covered_by_courses,
               collect(DISTINCT r.title) AS required_by_roles,
               count(DISTINCT j) AS job_count
        ORDER BY skill
        """
    )


def get_skill_detail(skill_name: str) -> Dict[str, Any]:
    rows = run_query(
        """
        MATCH (s:Skill {canonical_name: $skill})
        OPTIONAL MATCH (s)<-[:COVERS]-(t:Topic)<-[:HAS_TOPIC]-(m:Module)<-[:HAS_MODULE]-(c:Course)
        OPTIONAL MATCH (s)<-[:REQUIRES]-(j:JobDescription)<-[:HAS_DESCRIPTION]-(r:JobRole)
        RETURN s.canonical_name AS skill, s.category AS category,
               collect(DISTINCT c.name) AS covered_by_courses,
               collect(DISTINCT r.title) AS required_by_roles,
               count(DISTINCT j) AS job_count
        """,
        {"skill": skill_name},
    )
    return rows[0] if rows else None


def get_total_counts() -> Dict[str, int]:
    rows = run_query(
        """
        MATCH (c:Course) WITH count(c) AS course_count
        MATCH (s:Skill) WITH course_count, count(s) AS skill_count
        MATCH (j:JobDescription) WITH course_count, skill_count, count(j) AS job_count
        RETURN course_count, skill_count, job_count
        """
    )
    if rows:
        return rows[0]
    return {"course_count": 0, "skill_count": 0, "job_count": 0}


def get_subgraph(node_type: str = None, root_id: str = None, limit: int = 120) -> Dict[str, Any]:
    """
    Returns a filtered subgraph (nodes + edges) for the Knowledge Graph
    explorer. Always bounded by `limit` so the frontend never has to
    render an unreadable, unbounded graph.
    """
    if root_id:
        rows = run_query(
            """
            MATCH (root {id: $root_id})
            OPTIONAL MATCH path = (root)-[*1..2]-(neighbor)
            WITH root, collect(path) AS paths
            UNWIND (CASE WHEN size(paths) = 0 THEN [null] ELSE paths END) AS p
            RETURN root, p
            LIMIT $limit
            """,
            {"root_id": root_id, "limit": limit},
        )
    else:
        type_filter = f":{node_type}" if node_type else ""
        rows = run_query(
            f"""
            MATCH (n{type_filter})
            OPTIONAL MATCH (n)-[rel]->(m)
            RETURN n, rel, m
            LIMIT $limit
            """,
            {"limit": limit},
        )

    nodes: Dict[str, Dict[str, Any]] = {}
    edges = []

    def _add_node(node):
        if node is None:
            return
        node_id = node.get("id") or node.get("canonical_name")
        if node_id is None:
            return
        if node_id not in nodes:
            label = next(iter(node.labels), "Node") if hasattr(node, "labels") else "Node"
            name = node.get("name") or node.get("title") or node.get("canonical_name") or node_id
            nodes[node_id] = {"id": node_id, "label": label, "name": name}

    for row in rows:
        root = row.get("root") or row.get("n")
        _add_node(root)
        other = row.get("m")
        rel = row.get("rel")
        if row.get("p"):
            path = row["p"]
            for node in path.nodes:
                _add_node(node)
            for relationship in path.relationships:
                start_id = relationship.start_node.get("id") or relationship.start_node.get("canonical_name")
                end_id = relationship.end_node.get("id") or relationship.end_node.get("canonical_name")
                edges.append({"source": start_id, "target": end_id, "type": relationship.type})
        elif other is not None and rel is not None:
            _add_node(other)
            start_id = root.get("id") or root.get("canonical_name")
            end_id = other.get("id") or other.get("canonical_name")
            edges.append({"source": start_id, "target": end_id, "type": rel.type})

    return {"nodes": list(nodes.values()), "edges": edges}
