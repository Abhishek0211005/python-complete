"""
Dataset loading + ingestion orchestration.

Keeps a process-wide cache of the skill dictionary and raw JSON
datasets so repeated API calls don't re-read/re-parse files, and
exposes ingest_all_data() which populates Neo4j from those datasets
using graph_service.
"""
from functools import lru_cache
from typing import Any, Dict, List

from app.config import get_settings
from app.utils.file_parser import load_json
from app.utils.skill_normalizer import SkillDictionary, load_skill_dictionary


@lru_cache(maxsize=1)
def get_skill_dictionary() -> SkillDictionary:
    settings = get_settings()
    return load_skill_dictionary(settings.resolve_path(settings.skills_data_path))


@lru_cache(maxsize=1)
def get_curriculum_data() -> Dict[str, Any]:
    settings = get_settings()
    return load_json(settings.resolve_path(settings.curriculum_data_path))


@lru_cache(maxsize=1)
def get_jobs_data() -> List[Dict[str, Any]]:
    settings = get_settings()
    return load_json(settings.resolve_path(settings.jobs_data_path))


@lru_cache(maxsize=1)
def get_ground_truth_data() -> List[Dict[str, Any]]:
    settings = get_settings()
    return load_json(settings.resolve_path(settings.ground_truth_data_path))


def ingest_all_data() -> Dict[str, Any]:
    """Wipes and rebuilds the graph from the current datasets on disk."""
    from app.services import graph_service  # local import avoids a cycle at module load time

    skill_dictionary = get_skill_dictionary()
    graph_service.clear_graph()
    graph_service.setup_schema()
    curriculum_stats = graph_service.ingest_curriculum(get_curriculum_data(), skill_dictionary)
    job_stats = graph_service.ingest_jobs(get_jobs_data(), skill_dictionary)
    return {"curriculum": curriculum_stats, "jobs": job_stats}
