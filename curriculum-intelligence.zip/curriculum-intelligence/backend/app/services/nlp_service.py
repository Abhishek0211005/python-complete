"""
NLTK-based NLP pipeline.

Pipeline stages (mirrors the documented design):

    raw_text
      -> clean_text                (utils/text_cleaner.py)
      -> nltk.word_tokenize         (tokenization)
      -> stopword removal           (nltk.corpus.stopwords)
      -> WordNetLemmatizer          (lemmatization)
      -> candidate n-grams (1-3)    (for plain word/phrase skills)
      -> regex phrase match         (for punctuation-heavy skill names,
                                      run directly on cleaned text so
                                      names like "React.js" survive)
      -> normalize to canonical     (utils/skill_normalizer.py)

Both matching routes feed into one deduplicated set of canonical
Skill names -- this is what "skill extraction" returns.
"""
from functools import lru_cache
from typing import List

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize

from app.utils.text_cleaner import clean_text
from app.utils.skill_normalizer import SkillDictionary


def _ensure_nltk_data() -> None:
    """Download required NLTK corpora if not already present (idempotent)."""
    required = [
        ("tokenizers/punkt", "punkt"),
        ("tokenizers/punkt_tab", "punkt_tab"),
        ("corpora/stopwords", "stopwords"),
        ("corpora/wordnet", "wordnet"),
        ("corpora/omw-1.4", "omw-1.4"),
    ]
    for find_path, package in required:
        try:
            nltk.data.find(find_path)
        except LookupError:
            nltk.download(package, quiet=True)


_ensure_nltk_data()

_lemmatizer = WordNetLemmatizer()


@lru_cache(maxsize=1)
def _stopword_set():
    return set(stopwords.words("english"))


def tokenize_and_lemmatize(cleaned_text: str) -> List[str]:
    """Tokenize, remove stopwords/punctuation-only tokens, and lemmatize."""
    tokens = word_tokenize(cleaned_text.lower())
    stop_words = _stopword_set()
    lemmas = []
    for tok in tokens:
        if not tok.isalnum():
            continue
        if tok in stop_words:
            continue
        lemmas.append(_lemmatizer.lemmatize(tok))
    return lemmas


def build_ngrams(tokens: List[str], max_n: int = 3) -> List[str]:
    """Build 1..max_n grams (joined with a single space) from a token list."""
    ngrams = []
    n_tokens = len(tokens)
    for n in range(1, max_n + 1):
        for i in range(n_tokens - n + 1):
            ngrams.append(" ".join(tokens[i:i + n]))
    return ngrams


class NLPPipelineResult:
    def __init__(self, raw_text: str, cleaned_text: str, tokens: List[str], extracted_skills: List[str]):
        self.raw_text = raw_text
        self.cleaned_text = cleaned_text
        self.tokens = tokens
        self.extracted_skills = extracted_skills

    def to_dict(self):
        return {
            "cleaned_text": self.cleaned_text,
            "tokens_after_lemmatization": self.tokens,
            "extracted_skills": self.extracted_skills,
        }


def extract_skills(raw_text: str, skill_dictionary: SkillDictionary) -> NLPPipelineResult:
    """
    Run the full pipeline and return canonical skill names found in
    `raw_text`, along with the intermediate stages (useful for the
    /api/skills debug view and for viva demonstration).
    """
    cleaned = clean_text(raw_text)
    tokens = tokenize_and_lemmatize(cleaned)

    # Route 1: word/n-gram based matching against lemmatized tokens
    ngrams = build_ngrams(tokens, max_n=3)
    ngram_matches = set()
    for gram in ngrams:
        canonical = skill_dictionary.normalize_alias(gram)
        if canonical:
            ngram_matches.add(canonical)

    # Route 2: punctuation-safe regex phrase matching on cleaned text
    regex_matches = set(skill_dictionary.match_text(cleaned.lower()))

    all_skills = sorted(ngram_matches | regex_matches)
    return NLPPipelineResult(raw_text=raw_text, cleaned_text=cleaned, tokens=tokens, extracted_skills=all_skills)
