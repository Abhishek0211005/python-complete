"""
NetworkX analytics layer.

Neo4j answers relationship *queries* (e.g. "which skills does this
course cover"). NetworkX is where we run graph-theoretic *algorithms*
over the job-description <-> skill relationships that Neo4j hands us:

  - degree centrality of each Skill node within the job-skill bipartite
    graph -> used as the "industry demand weight" in weighted alignment
    and as the importance signal for recommendation priority.
  - overall graph statistics (node/edge counts, density, average degree)
    -> surfaced on the dashboard/reports as genuine graph metrics.

The bipartite graph is built fresh from whatever job list is passed in
(all jobs, or a role-filtered subset), so results are always freshly
calculated -- never hard-coded.
"""
from typing import Any, Dict, List

import networkx as nx


def build_job_skill_graph(jobs: List[Dict[str, Any]]) -> nx.Graph:
    """
    jobs: list of dicts, each with at least {"id": ..., "skills": [...]}.
    Returns a bipartite undirected graph: job nodes ("job:<id>") and
    skill nodes ("skill:<name>"), connected by an edge whenever a job
    requires that skill.
    """
    graph = nx.Graph()
    for job in jobs:
        job_node = f"job:{job['id']}"
        graph.add_node(job_node, bipartite="job", label=job.get("title", job["id"]))
        for skill in job.get("skills", []):
            skill_node = f"skill:{skill}"
            graph.add_node(skill_node, bipartite="skill", label=skill)
            graph.add_edge(job_node, skill_node)
    return graph


def skill_demand(jobs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Computes, for every skill appearing in `jobs`, the fraction of jobs
    that require it, using degree centrality on the bipartite graph
    (a skill's degree here literally equals the number of jobs requiring
    it, so degree centrality normalized by job-node count gives an
    industry-demand percentage grounded in real graph structure).
    """
    graph = build_job_skill_graph(jobs)
    total_jobs = sum(1 for _, data in graph.nodes(data=True) if data.get("bipartite") == "job")
    if total_jobs == 0:
        return []

    centrality = nx.degree_centrality(graph)
    results = []
    for node, data in graph.nodes(data=True):
        if data.get("bipartite") != "skill":
            continue
        jobs_requiring = graph.degree(node)
        demand_pct = round(100.0 * jobs_requiring / total_jobs, 2)
        results.append({
            "skill": data["label"],
            "jobs_requiring": jobs_requiring,
            "total_jobs": total_jobs,
            "demand_percentage": demand_pct,
            "degree_centrality": round(centrality.get(node, 0.0), 4),
        })
    results.sort(key=lambda r: r["demand_percentage"], reverse=True)
    return results


def graph_statistics(jobs: List[Dict[str, Any]]) -> Dict[str, Any]:
    graph = build_job_skill_graph(jobs)
    job_nodes = [n for n, d in graph.nodes(data=True) if d.get("bipartite") == "job"]
    skill_nodes = [n for n, d in graph.nodes(data=True) if d.get("bipartite") == "skill"]

    if graph.number_of_nodes() == 0:
        return {
            "job_nodes": 0, "skill_nodes": 0, "edges": 0,
            "density": 0.0, "average_skills_per_job": 0.0,
        }

    avg_skills_per_job = (
        sum(graph.degree(n) for n in job_nodes) / len(job_nodes) if job_nodes else 0.0
    )

    return {
        "job_nodes": len(job_nodes),
        "skill_nodes": len(skill_nodes),
        "edges": graph.number_of_edges(),
        "density": round(nx.density(graph), 4),
        "average_skills_per_job": round(avg_skills_per_job, 2),
    }


def top_skills(jobs: List[Dict[str, Any]], top_n: int = 10) -> List[Dict[str, Any]]:
    return skill_demand(jobs)[:top_n]
