"""
Rule-based recommendation engine.

Priority is derived purely from calculated industry demand percentage
(from networkx_service, fed through gap_service):

    demand >= 70%              -> HIGH
    40% <= demand < 70%        -> MEDIUM
    demand < 40%                -> LOW

Recommendation text is templated per skill *category* (not hand-written
per individual skill) so the logic stays maintainable and explainable
for a viva: "this is a lookup table keyed by category, not free text."
"""
from typing import Any, Dict, List

from app.services import gap_service
from app.utils.skill_normalizer import SkillDictionary

HIGH_THRESHOLD = 70.0
MEDIUM_THRESHOLD = 40.0

CATEGORY_TEMPLATES = {
    "DevOps & Cloud": "Introduce {skill} fundamentals and a hands-on practical into the {course} module.",
    "Frontend Development": "Introduce {skill} in the Frontend Engineering module of {course}, building on existing JavaScript/React content.",
    "Backend Development": "Add {skill} coverage to the Backend Engineering module of {course}.",
    "Database": "Introduce {skill} concepts within the database-related module of {course}.",
    "Machine Learning": "Add {skill} to the Machine Learning course with a practical lab component.",
    "Data Science & Analytics": "Introduce {skill} as part of the data analysis coursework in {course}.",
    "Programming Languages": "Introduce {skill} fundamentals early in the {course} curriculum.",
    "Mobile Development": "Add {skill} coverage to the Mobile Application Development course.",
    "Tools & Version Control": "Incorporate {skill} practices into project-based coursework in {course}.",
}

DEFAULT_TEMPLATE = "Introduce {skill} into the {course} curriculum through a dedicated topic or practical."


def _priority_for_demand(demand_pct: float) -> str:
    if demand_pct >= HIGH_THRESHOLD:
        return "HIGH"
    if demand_pct >= MEDIUM_THRESHOLD:
        return "MEDIUM"
    return "LOW"


def generate_recommendations(course_id: str, role_id: str, course_name: str, role_title: str,
                              skill_dictionary: SkillDictionary) -> List[Dict[str, Any]]:
    gap_result = gap_service.analyze_gap(course_id, role_id)
    demand_by_skill = gap_result["skill_demand"]

    recommendations = []
    for skill in gap_result["missing_skills"]:
        demand_row = demand_by_skill[skill]
        demand_pct = demand_row["demand_percentage"]
        priority = _priority_for_demand(demand_pct)
        category = skill_dictionary.category_of(skill)
        template = CATEGORY_TEMPLATES.get(category, DEFAULT_TEMPLATE)

        recommendations.append({
            "skill": skill,
            "category": category,
            "industry_demand_percentage": demand_pct,
            "jobs_requiring": demand_row["jobs_requiring"],
            "total_relevant_jobs": demand_row["total_jobs"],
            "curriculum_coverage": "Not Covered",
            "priority": priority,
            "reason": (
                f"{skill} appears in {demand_pct}% of analyzed {role_title} job descriptions "
                f"but is not currently covered by the {course_name} curriculum."
            ),
            "recommendation": template.format(skill=skill, course=course_name),
        })

    priority_rank = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    recommendations.sort(key=lambda r: (priority_rank[r["priority"]], -r["industry_demand_percentage"]))
    return recommendations
