"""
Skill-gap and alignment calculation.

Nothing here is precomputed or hard-coded: curriculum_skills and
industry_skills are pulled fresh via graph_service (Neo4j), and demand
weights come fresh from networkx_service on every call.
"""
from typing import Any, Dict, List

from app.services import graph_service, networkx_service

CRITICAL_DEMAND_THRESHOLD = 70.0


def analyze_gap(course_id: str, role_id: str) -> Dict[str, Any]:
    curriculum_skills = set(graph_service.get_course_skills(course_id))

    role_jobs = graph_service.get_jobs(role_id=role_id)
    demand_rows = networkx_service.skill_demand(role_jobs)
    demand_by_skill = {row["skill"]: row for row in demand_rows}
    industry_skills = set(demand_by_skill.keys())

    covered = sorted(curriculum_skills & industry_skills)
    missing = sorted(industry_skills - curriculum_skills)
    critical = sorted(
        s for s in missing if demand_by_skill[s]["demand_percentage"] >= CRITICAL_DEMAND_THRESHOLD
    )

    required_count = len(industry_skills)
    covered_count = len(covered)

    basic_alignment = round(100.0 * covered_count / required_count, 2) if required_count else 0.0

    total_weight = sum(demand_by_skill[s]["demand_percentage"] for s in industry_skills)
    covered_weight = sum(demand_by_skill[s]["demand_percentage"] for s in covered)
    weighted_alignment = round(100.0 * covered_weight / total_weight, 2) if total_weight else 0.0

    return {
        "course_id": course_id,
        "role_id": role_id,
        "curriculum_skills": sorted(curriculum_skills),
        "industry_skills": sorted(industry_skills),
        "covered_skills": covered,
        "missing_skills": missing,
        "critical_skills": critical,
        "basic_alignment_percentage": basic_alignment,
        "weighted_alignment_percentage": weighted_alignment,
        "skill_demand": demand_by_skill,
        "required_skill_count": required_count,
        "covered_skill_count": covered_count,
    }
