"""
One-time generator for the sample industry job-description dataset.
Produces datasets/job_descriptions/jobs.json with multiple postings per
role so that skill-demand percentages are meaningful (not single-sample).

This is a development dataset only -- it is deliberately varied (not
every posting for a role lists identical skills) so that demand-percentage
and centrality calculations downstream are genuine, not trivial 100%/0%
splits.
"""
import json
import random
from pathlib import Path

random.seed(42)

OUT_PATH = Path(__file__).resolve().parent.parent.parent / "datasets" / "job_descriptions" / "jobs.json"

ROLES = {
    "Full Stack Developer": {
        "industry": "IT Services",
        "core": ["React.js", "Node.js", "JavaScript", "Git", "REST API"],
        "extra": ["MongoDB", "Docker", "AWS", "TypeScript", "Express.js", "Redux", "GraphQL"],
        "company_pool": ["Acme Software Pvt Ltd", "Brightline Technologies", "Nimbus Digital", "Vertex Softworks"],
    },
    "Frontend Developer": {
        "industry": "IT Services",
        "core": ["HTML", "CSS", "JavaScript", "React.js"],
        "extra": ["TypeScript", "Redux", "Git", "Vue.js", "Angular"],
        "company_pool": ["PixelCraft Studio", "Brightline Technologies", "Nimbus Digital", "Clearwave Labs"],
    },
    "Backend Developer": {
        "industry": "IT Services",
        "core": ["Python", "REST API", "SQL", "Git"],
        "extra": ["FastAPI", "Django", "Flask", "PostgreSQL", "MongoDB", "Docker", "Microservices", "Redis"],
        "company_pool": ["Acme Software Pvt Ltd", "Corestack Systems", "Vertex Softworks", "Databay Technologies"],
    },
    "Data Analyst": {
        "industry": "Analytics & BI",
        "core": ["SQL", "Excel", "Power BI", "Statistics"],
        "extra": ["Python", "Pandas", "Tableau", "Data Visualization", "NumPy"],
        "company_pool": ["Insightify Analytics", "Databay Technologies", "Clearwave Labs", "Northbridge Consulting"],
    },
    "Data Scientist": {
        "industry": "Analytics & BI",
        "core": ["Python", "Machine Learning", "Pandas", "Statistics"],
        "extra": ["Scikit-learn", "TensorFlow", "Deep Learning", "SQL", "NumPy", "NLP", "PyTorch"],
        "company_pool": ["Insightify Analytics", "Northbridge Consulting", "Databay Technologies", "Corestack Systems"],
    },
    "Machine Learning Engineer": {
        "industry": "Analytics & BI",
        "core": ["Python", "Machine Learning", "TensorFlow", "Deep Learning"],
        "extra": ["PyTorch", "Scikit-learn", "Docker", "AWS", "NLP", "Spark"],
        "company_pool": ["Northbridge Consulting", "Insightify Analytics", "Vertex Softworks", "Corestack Systems"],
    },
    "Cloud Engineer": {
        "industry": "Cloud & Infrastructure",
        "core": ["AWS", "Linux", "Docker", "Git"],
        "extra": ["Kubernetes", "Azure", "Google Cloud", "Terraform", "CI/CD", "Nginx", "Jenkins"],
        "company_pool": ["Corestack Systems", "Vertex Softworks", "Clearwave Labs", "Skyline Cloud Services"],
    },
    "DevOps Engineer": {
        "industry": "Cloud & Infrastructure",
        "core": ["Docker", "CI/CD", "Linux", "Git"],
        "extra": ["Kubernetes", "Jenkins", "AWS", "Terraform", "Azure", "Nginx"],
        "company_pool": ["Skyline Cloud Services", "Corestack Systems", "Vertex Softworks", "Brightline Technologies"],
    },
    "Mobile App Developer": {
        "industry": "IT Services",
        "core": ["Flutter", "Dart", "REST API", "Git"],
        "extra": ["Firebase", "Kotlin", "Android", "Swift"],
        "company_pool": ["PixelCraft Studio", "Nimbus Digital", "Clearwave Labs", "Acme Software Pvt Ltd"],
    },
}

LOCATIONS = ["Bengaluru", "Pune", "Hyderabad", "Chandigarh", "Gurugram", "Remote", "Noida", "Chennai"]

TEMPLATES = [
    "We are looking for a {role} to join our team. The ideal candidate has hands-on experience with {skills}. You will work closely with a cross-functional team to design, build and maintain scalable solutions.",
    "Our client is hiring a {role} with strong practical knowledge of {skills}. Responsibilities include developing, testing and deploying production-grade solutions in an agile environment.",
    "As a {role}, you will be responsible for building and maintaining systems using {skills}. Prior industry experience with these technologies is required for this role.",
    "We need an experienced {role} skilled in {skills} to help scale our engineering team. You will collaborate with senior engineers and contribute to architecture decisions.",
    "Exciting opportunity for a {role} proficient in {skills}. The role involves working on real-world projects with a strong emphasis on code quality and performance.",
]


def format_skill_list(skills):
    if len(skills) == 1:
        return skills[0]
    return ", ".join(skills[:-1]) + " and " + skills[-1]


def build_description(role, skills):
    template = random.choice(TEMPLATES)
    return template.format(role=role, skills=format_skill_list(skills))


def generate():
    jobs = []
    job_counter = 1
    for role, cfg in ROLES.items():
        num_postings = random.randint(8, 12)
        for _ in range(num_postings):
            skills = list(cfg["core"])
            # randomly include a variable subset of "extra" skills so demand
            # percentages differ meaningfully instead of being uniform
            extra_pool = cfg["extra"][:]
            random.shuffle(extra_pool)
            num_extra = random.randint(2, min(5, len(extra_pool)))
            skills += extra_pool[:num_extra]
            random.shuffle(skills)

            job = {
                "job_id": f"JD-{job_counter:04d}",
                "job_title": role,
                "company": random.choice(cfg["company_pool"]),
                "industry": cfg["industry"],
                "location": random.choice(LOCATIONS),
                "source": "sample_dataset",
                "description": build_description(role, skills),
            }
            jobs.append(job)
            job_counter += 1

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        json.dump(jobs, f, indent=2)
    print(f"Generated {len(jobs)} job descriptions -> {OUT_PATH}")


def generate_ground_truth():
    """
    Build a labeled evaluation subset. Because this development dataset is
    template-generated, the exact skill terms embedded in each description
    are known with certainty -- so the "ground truth" below is a faithful
    substitute for manual human labeling (a human labeler reading these
    same descriptions would land on the same skill set). In a real-world
    deployment this file would instead be produced by a human annotator
    reading actual job postings.
    """
    jobs = json.load(open(OUT_PATH, encoding="utf-8"))
    sample = random.sample(jobs, 40)
    ground_truth = []
    for job in sample:
        desc = job["description"]
        mentioned = []
        for role_cfg in ROLES.values():
            for skill in role_cfg["core"] + role_cfg["extra"]:
                if skill.lower() in desc.lower() and skill not in mentioned:
                    mentioned.append(skill)
        ground_truth.append({
            "job_id": job["job_id"],
            "text": desc,
            "ground_truth_skills": sorted(mentioned),
        })
    gt_path = OUT_PATH.parent.parent / "ground_truth" / "labeled_jobs.json"
    gt_path.parent.mkdir(parents=True, exist_ok=True)
    with open(gt_path, "w", encoding="utf-8") as f:
        json.dump(ground_truth, f, indent=2)
    print(f"Generated {len(ground_truth)} ground-truth labels -> {gt_path}")


if __name__ == "__main__":
    generate()
    generate_ground_truth()
